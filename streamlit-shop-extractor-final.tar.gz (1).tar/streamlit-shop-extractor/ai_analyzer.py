#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI Analyzer for Egyptian Shop Data
Categorizes shops and predicts revenue potential using text analysis and heuristics
"""

import pandas as pd
import re
from typing import Dict, List
import logging

logger = logging.getLogger(__name__)


class ShopAIAnalyzer:
    """AI-powered shop categorization and revenue prediction"""
    
    def __init__(self):
        # Category keywords (Arabic and English)
        self.category_keywords = {
            'clothing': {
                'ar': ['ملابس', 'أزياء', 'موضة', 'فساتين', 'قمصان', 'بنطلون', 'جينز', 'عبايات', 'حجاب'],
                'en': ['clothing', 'fashion', 'apparel', 'dress', 'shirt', 'pants', 'jeans', 'wear', 'boutique']
            },
            'food': {
                'ar': ['طعام', 'مطعم', 'كافيه', 'مقهى', 'وجبات', 'مأكولات', 'حلويات', 'مخبز', 'فطائر'],
                'en': ['food', 'restaurant', 'cafe', 'coffee', 'meals', 'cuisine', 'bakery', 'pizza', 'burger']
            },
            'electronics': {
                'ar': ['إلكترونيات', 'موبايل', 'كمبيوتر', 'لابتوب', 'تليفون', 'هاتف', 'أجهزة'],
                'en': ['electronics', 'mobile', 'computer', 'laptop', 'phone', 'devices', 'gadget', 'tech']
            },
            'beauty': {
                'ar': ['تجميل', 'مكياج', 'عطور', 'صالون', 'حلاق', 'عناية', 'بشرة', 'شعر'],
                'en': ['beauty', 'makeup', 'cosmetic', 'salon', 'hair', 'perfume', 'skincare', 'spa']
            },
            'jewelry': {
                'ar': ['مجوهرات', 'ذهب', 'فضة', 'إكسسوارات', 'خواتم', 'أساور'],
                'en': ['jewelry', 'gold', 'silver', 'accessories', 'rings', 'necklace', 'bracelet']
            },
            'home': {
                'ar': ['أثاث', 'منزل', 'ديكور', 'مفروشات', 'أدوات منزلية'],
                'en': ['furniture', 'home', 'decor', 'furnishing', 'homeware', 'interior']
            },
            'automotive': {
                'ar': ['سيارات', 'قطع غيار', 'ورشة', 'صيانة', 'معرض'],
                'en': ['car', 'auto', 'vehicle', 'spare parts', 'garage', 'automotive', 'workshop']
            },
            'pharmacy': {
                'ar': ['صيدلية', 'أدوية', 'دواء'],
                'en': ['pharmacy', 'medicine', 'drug', 'pharmaceutical']
            },
            'supermarket': {
                'ar': ['سوبر ماركت', 'بقالة', 'هايبر', 'تموينات'],
                'en': ['supermarket', 'grocery', 'mart', 'hypermarket', 'store']
            },
            'services': {
                'ar': ['خدمات', 'صيانة', 'تصليح', 'نقل', 'تنظيف'],
                'en': ['service', 'repair', 'maintenance', 'cleaning', 'moving']
            }
        }
        
        # Revenue indicators
        self.high_revenue_indicators = [
            'chain', 'branch', 'شركة', 'mall', 'center', 'luxury', 'premium',
            'international', 'franchise', 'group', 'مجموعة', 'فرع'
        ]
        
        self.location_premium = {
            'high': ['مول', 'سيتي ستارز', 'mall', 'downtown', 'zamalek', 'الزمالك', 
                    'heliopolis', 'مصر الجديدة', 'maadi', 'المعادي', '6 october', 
                    'الشيخ زايد', 'sheikh zayed', 'new cairo', 'القاهرة الجديدة'],
            'medium': ['nasr city', 'مدينة نصر', 'giza', 'الجيزة', 'شبرا', 'mohandessin', 'المهندسين'],
            'low': []
        }
    
    def categorize_shop(self, row: pd.Series) -> str:
        """Categorize shop based on name, products, and other text fields"""
        
        # Combine all text fields for analysis
        text_fields = [
            str(row.get('shop_name', '')),
            str(row.get('products', '')),
            str(row.get('address', '')),
            str(row.get('category', ''))
        ]
        combined_text = ' '.join(text_fields).lower()
        
        # Score each category
        category_scores = {}
        for category, keywords in self.category_keywords.items():
            score = 0
            for keyword in keywords['ar'] + keywords['en']:
                if keyword.lower() in combined_text:
                    score += 1
            category_scores[category] = score
        
        # Get category with highest score
        if max(category_scores.values()) > 0:
            return max(category_scores, key=category_scores.get)
        else:
            return 'other'
    
    def predict_revenue_potential(self, row: pd.Series) -> Dict:
        """Predict revenue potential based on multiple factors"""
        
        score = 0
        factors = []
        
        # Factor 1: Online presence (0-30 points)
        online_channels = 0
        if pd.notna(row.get('website')) and row.get('website'):
            online_channels += 1
            score += 10
            factors.append('Has website (+10)')
        if pd.notna(row.get('instagram')) and row.get('instagram'):
            online_channels += 1
            score += 7
            factors.append('Has Instagram (+7)')
        if pd.notna(row.get('facebook')) and row.get('facebook'):
            online_channels += 1
            score += 7
            factors.append('Has Facebook (+7)')
        if pd.notna(row.get('whatsapp')) and row.get('whatsapp'):
            online_channels += 1
            score += 6
            factors.append('Has WhatsApp (+6)')
        
        # Factor 2: Contact information completeness (0-20 points)
        if pd.notna(row.get('phone')) and row.get('phone'):
            score += 10
            factors.append('Has phone (+10)')
        if pd.notna(row.get('email')) and row.get('email'):
            score += 10
            factors.append('Has email (+10)')
        
        # Factor 3: Business type indicators (0-25 points)
        combined_text = ' '.join([
            str(row.get('shop_name', '')),
            str(row.get('products', '')),
            str(row.get('address', ''))
        ]).lower()
        
        for indicator in self.high_revenue_indicators:
            if indicator in combined_text:
                score += 5
                factors.append(f'Business indicator: {indicator} (+5)')
                break
        
        # Factor 4: Location premium (0-25 points)
        address = str(row.get('address', '')).lower()
        location_score = 0
        for location in self.location_premium['high']:
            if location in address:
                location_score = 25
                factors.append(f'Premium location (+25)')
                break
        
        if location_score == 0:
            for location in self.location_premium['medium']:
                if location in address:
                    location_score = 15
                    factors.append(f'Good location (+15)')
                    break
        
        if location_score == 0:
            location_score = 5
            factors.append('Standard location (+5)')
        
        score += location_score
        
        # Calculate final rating
        if score >= 70:
            rating = 'High'
            emoji = '🔥'
        elif score >= 45:
            rating = 'Medium-High'
            emoji = '⭐'
        elif score >= 25:
            rating = 'Medium'
            emoji = '✓'
        else:
            rating = 'Low'
            emoji = '📊'
        
        return {
            'revenue_score': score,
            'revenue_rating': rating,
            'revenue_emoji': emoji,
            'analysis_factors': factors
        }
    
    def analyze_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """Analyze entire dataframe and add AI insights"""
        
        if df.empty:
            return df
        
        logger.info("Starting AI analysis...")
        
        # Add category column
        df['ai_category'] = df.apply(self.categorize_shop, axis=1)
        
        # Add revenue prediction columns
        revenue_data = df.apply(self.predict_revenue_potential, axis=1)
        df['revenue_score'] = revenue_data.apply(lambda x: x['revenue_score'])
        df['revenue_rating'] = revenue_data.apply(lambda x: x['revenue_rating'])
        df['revenue_emoji'] = revenue_data.apply(lambda x: x['revenue_emoji'])
        
        # Sort by revenue score
        df = df.sort_values('revenue_score', ascending=False)
        
        logger.info("AI analysis completed!")
        logger.info(f"\nCategory Distribution:")
        logger.info(df['ai_category'].value_counts())
        logger.info(f"\nRevenue Rating Distribution:")
        logger.info(df['revenue_rating'].value_counts())
        
        return df
    
    def generate_insights_report(self, df: pd.DataFrame) -> str:
        """Generate text report with insights"""
        
        if df.empty:
            return "No data available for analysis."
        
        report = []
        report.append("=" * 70)
        report.append("📊 AI ANALYSIS REPORT - EGYPTIAN SHOPS")
        report.append("=" * 70)
        report.append("")
        
        # Overall stats
        report.append(f"Total Shops Analyzed: {len(df)}")
        report.append(f"Shops with Complete Contact Info: {df[['phone', 'email']].notna().all(axis=1).sum()}")
        report.append(f"Shops with Social Media: {df[['instagram', 'facebook']].notna().any(axis=1).sum()}")
        report.append("")
        
        # Category breakdown
        report.append("📁 CATEGORY DISTRIBUTION:")
        report.append("-" * 70)
        category_counts = df['ai_category'].value_counts()
        for category, count in category_counts.items():
            percentage = (count / len(df)) * 100
            report.append(f"  {category.upper():20s}: {count:3d} shops ({percentage:5.1f}%)")
        report.append("")
        
        # Revenue potential
        report.append("💰 REVENUE POTENTIAL DISTRIBUTION:")
        report.append("-" * 70)
        revenue_counts = df['revenue_rating'].value_counts()
        for rating, count in revenue_counts.items():
            percentage = (count / len(df)) * 100
            report.append(f"  {rating:20s}: {count:3d} shops ({percentage:5.1f}%)")
        report.append("")
        
        # Top 10 highest potential shops
        report.append("🔥 TOP 10 HIGH-POTENTIAL SHOPS:")
        report.append("-" * 70)
        top_shops = df.nlargest(10, 'revenue_score')[['shop_name', 'revenue_score', 'revenue_rating', 'ai_category']]
        for idx, row in top_shops.iterrows():
            emoji = '🔥' if row['revenue_rating'] == 'High' else '⭐' if row['revenue_rating'] == 'Medium-High' else '✓' if row['revenue_rating'] == 'Medium' else '📊'
            report.append(f"  {emoji} {row['shop_name'][:40]:40s} | Score: {row['revenue_score']:3d} | {row['ai_category']}")
        report.append("")
        
        # Recommendations
        report.append("💡 RECOMMENDATIONS:")
        report.append("-" * 70)
        
        high_potential = len(df[df['revenue_rating'] == 'High'])
        if high_potential > 0:
            report.append(f"  ✅ Priority: Focus on {high_potential} HIGH-rated shops first")
        
        no_social = len(df[(df['instagram'].isna()) & (df['facebook'].isna())])
        if no_social > 0:
            report.append(f"  📱 Opportunity: {no_social} shops lack social media presence")
        
        no_website = len(df[df['website'].isna()])
        if no_website > 0:
            report.append(f"  🌐 Digital Gap: {no_website} shops have no website")
        
        report.append("")
        report.append("=" * 70)
        
        return "\n".join(report)


def main():
    """Test the analyzer with sample data"""
    
    # Create sample data
    sample_data = {
        'shop_name': ['ملابس الموضة', 'مطعم الفلاح', 'صيدلية النور'],
        'phone': ['+201234567890', '+201234567891', '+201234567892'],
        'email': ['info@fashion.com', '', 'nour@pharmacy.com'],
        'address': ['مول العرب، الشيخ زايد', 'شارع الهرم، الجيزة', 'مدينة نصر، القاهرة'],
        'instagram': ['@fashion', '', '@nour'],
        'facebook': ['facebook.com/fashion', 'facebook.com/falla7', ''],
        'whatsapp': ['wa.me/201234567890', 'wa.me/201234567891', 'wa.me/201234567892'],
        'website': ['fashion.com', '', 'nourpharmacy.com'],
        'products': ['فساتين، بناطيل، قمصان', 'كشري، فول، طعمية', 'أدوية، مستحضرات تجميل']
    }
    
    df = pd.DataFrame(sample_data)
    
    # Analyze
    analyzer = ShopAIAnalyzer()
    df_analyzed = analyzer.analyze_dataframe(df)
    
    print(df_analyzed[['shop_name', 'ai_category', 'revenue_score', 'revenue_rating']])
    print("\n" + analyzer.generate_insights_report(df_analyzed))


if __name__ == "__main__":
    main()
