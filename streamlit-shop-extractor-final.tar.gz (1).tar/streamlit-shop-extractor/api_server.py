#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
API Server for Egyptian Shop Extractor
RESTful API for integration with Sellfast SaaS
"""

from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import pandas as pd
import uuid
import os
from datetime import datetime
import threading
import logging

from extractor import ShopDataExtractor
from ai_analyzer import ShopAIAnalyzer

app = Flask(__name__)
CORS(app)  # Enable CORS for cross-origin requests

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Storage for extraction jobs
jobs = {}
RESULTS_DIR = 'api_results'
os.makedirs(RESULTS_DIR, exist_ok=True)


def run_extraction(job_id, urls, max_pages, include_ai):
    """Background task for extraction"""
    try:
        jobs[job_id]['status'] = 'running'
        jobs[job_id]['progress'] = 'Extracting data...'
        
        # Extract data
        extractor = ShopDataExtractor()
        df = extractor.scrape_multiple_urls(urls, max_pages_per_url=max_pages)
        
        if df.empty:
            jobs[job_id]['status'] = 'failed'
            jobs[job_id]['error'] = 'No data extracted'
            return
        
        # AI Analysis
        if include_ai:
            jobs[job_id]['progress'] = 'Running AI analysis...'
            analyzer = ShopAIAnalyzer()
            df = analyzer.analyze_dataframe(df)
        
        # Save results
        jobs[job_id]['progress'] = 'Saving results...'
        output_file = os.path.join(RESULTS_DIR, f'{job_id}.xlsx')
        csv_file = os.path.join(RESULTS_DIR, f'{job_id}.csv')
        
        extractor.clean_and_export(df, output_file)
        df.to_csv(csv_file, index=False, encoding='utf-8-sig')
        
        # Update job status
        jobs[job_id]['status'] = 'completed'
        jobs[job_id]['progress'] = 'Done'
        jobs[job_id]['total_leads'] = len(df)
        jobs[job_id]['output_file'] = output_file
        jobs[job_id]['csv_file'] = csv_file
        jobs[job_id]['completed_at'] = datetime.now().isoformat()
        
        # Store sample results
        jobs[job_id]['sample_results'] = df.head(10).to_dict('records')
        
    except Exception as e:
        logger.error(f"Extraction error for job {job_id}: {e}")
        jobs[job_id]['status'] = 'failed'
        jobs[job_id]['error'] = str(e)


@app.route('/')
def index():
    """API documentation"""
    return jsonify({
        'name': 'Egyptian Shop Extractor API',
        'version': '1.0.0',
        'description': 'RESTful API for extracting Egyptian shop data',
        'endpoints': {
            'POST /api/extract': 'Start extraction job',
            'GET /api/status/<job_id>': 'Check job status',
            'GET /api/download/<job_id>': 'Download results (Excel)',
            'GET /api/download/<job_id>/csv': 'Download results (CSV)',
            'GET /api/jobs': 'List all jobs'
        }
    })


@app.route('/api/extract', methods=['POST'])
def create_extraction():
    """
    Start a new extraction job
    
    Body:
    {
        "urls": ["url1", "url2"],
        "max_pages": 10,
        "include_ai": true
    }
    """
    try:
        data = request.json
        urls = data.get('urls', [])
        max_pages = data.get('max_pages', 10)
        include_ai = data.get('include_ai', True)
        
        if not urls:
            return jsonify({'error': 'No URLs provided'}), 400
        
        # Create job
        job_id = str(uuid.uuid4())
        jobs[job_id] = {
            'id': job_id,
            'status': 'pending',
            'progress': 'Initializing...',
            'urls': urls,
            'max_pages': max_pages,
            'include_ai': include_ai,
            'created_at': datetime.now().isoformat(),
            'total_leads': 0
        }
        
        # Start extraction in background
        thread = threading.Thread(
            target=run_extraction,
            args=(job_id, urls, max_pages, include_ai)
        )
        thread.daemon = True
        thread.start()
        
        return jsonify({
            'job_id': job_id,
            'status': 'pending',
            'message': 'Extraction job created successfully'
        }), 201
        
    except Exception as e:
        logger.error(f"Error creating extraction job: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/status/<job_id>', methods=['GET'])
def get_status(job_id):
    """Get job status"""
    if job_id not in jobs:
        return jsonify({'error': 'Job not found'}), 404
    
    job = jobs[job_id]
    
    response = {
        'job_id': job_id,
        'status': job['status'],
        'progress': job['progress'],
        'created_at': job['created_at'],
        'total_leads': job.get('total_leads', 0)
    }
    
    if job['status'] == 'completed':
        response['completed_at'] = job.get('completed_at')
        response['download_url'] = f'/api/download/{job_id}'
        response['csv_url'] = f'/api/download/{job_id}/csv'
        response['sample_results'] = job.get('sample_results', [])
    
    if job['status'] == 'failed':
        response['error'] = job.get('error')
    
    return jsonify(response)


@app.route('/api/download/<job_id>', methods=['GET'])
def download_results(job_id):
    """Download Excel results"""
    if job_id not in jobs:
        return jsonify({'error': 'Job not found'}), 404
    
    job = jobs[job_id]
    
    if job['status'] != 'completed':
        return jsonify({'error': 'Job not completed yet'}), 400
    
    output_file = job.get('output_file')
    if not output_file or not os.path.exists(output_file):
        return jsonify({'error': 'Result file not found'}), 404
    
    return send_file(
        output_file,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name=f'egyptian_shops_{job_id}.xlsx'
    )


@app.route('/api/download/<job_id>/csv', methods=['GET'])
def download_csv(job_id):
    """Download CSV results"""
    if job_id not in jobs:
        return jsonify({'error': 'Job not found'}), 404
    
    job = jobs[job_id]
    
    if job['status'] != 'completed':
        return jsonify({'error': 'Job not completed yet'}), 400
    
    csv_file = job.get('csv_file')
    if not csv_file or not os.path.exists(csv_file):
        return jsonify({'error': 'CSV file not found'}), 404
    
    return send_file(
        csv_file,
        mimetype='text/csv',
        as_attachment=True,
        download_name=f'egyptian_shops_{job_id}.csv'
    )


@app.route('/api/jobs', methods=['GET'])
def list_jobs():
    """List all jobs"""
    return jsonify({
        'total_jobs': len(jobs),
        'jobs': list(jobs.values())
    })


if __name__ == '__main__':
    print("""
╔════════════════════════════════════════════════════════════════╗
║                                                                ║
║        🚀 EGYPTIAN SHOP EXTRACTOR API SERVER                  ║
║                                                                ║
║        API for Sellfast SaaS Integration                      ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝

Server running on: http://localhost:5000

API Endpoints:
  • POST   /api/extract          - Start extraction
  • GET    /api/status/<job_id>  - Check status
  • GET    /api/download/<job_id> - Download Excel
  • GET    /api/jobs             - List all jobs

Example Request:
  curl -X POST http://localhost:5000/api/extract \\
    -H "Content-Type: application/json" \\
    -d '{"urls": ["https://example.com"], "max_pages": 5}'
    """)
    
    app.run(debug=True, host='0.0.0.0', port=5000)
