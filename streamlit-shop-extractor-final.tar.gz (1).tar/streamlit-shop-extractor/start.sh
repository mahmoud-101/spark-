#!/bin/bash
# Quick Start Script for Mobile/Termux

echo "🛍️ Egyptian Business Extractor - Quick Start"
echo "=============================================="
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python not found. Installing..."
    pkg install python -y
fi

# Check if pip is installed
if ! command -v pip &> /dev/null; then
    echo "❌ pip not found. Installing..."
    pkg install python-pip -y
fi

echo "✅ Python is installed"
echo ""

# Install essential requirements only
echo "📦 Installing essential packages..."
pip install --quiet streamlit pandas openpyxl beautifulsoup4 requests phonenumbers email-validator

if [ $? -eq 0 ]; then
    echo "✅ Packages installed successfully"
else
    echo "⚠️ Some packages failed to install. Trying one by one..."
    pip install streamlit
    pip install pandas
    pip install beautifulsoup4
    pip install requests
fi

echo ""
echo "🚀 Starting application..."
echo "📱 Open browser and go to: http://localhost:8501"
echo "⚠️ Press Ctrl+C to stop"
echo ""

# Start Streamlit
streamlit run app.py --server.headless true --server.port 8501
