#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Complete Egyptian Shop Extractor with AI Analysis
Combines all extractors + AI analyzer for full pipeline
"""

import sys
import os
import argparse
import pandas as pd
from pathlib import Path

# Import our modules
from extractor import ShopDataExtractor
from ai_analyzer import ShopAIAnalyzer
from google_maps_extractor import GoogleMapsExtractor

import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def print_banner():
    """Print welcome banner"""
    banner = """
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║       🛍️  EGYPTIAN SHOP DATA EXTRACTOR & ANALYZER  🛍️              ║
║                                                                      ║
║                  للاستخراج البيانات المحلات المصرية                  ║
║                                                                      ║
╠══════════════════════════════════════════════════════════════════════╣
║                                                                      ║
║  ✅ Extract: Shop names, phones, emails, addresses, social media    ║
║  ✅ Analyze: AI categorization & revenue potential prediction       ║
║  ✅ Export: Clean Excel/CSV with 100+ validated leads              ║
║  ✅ Support: Arabic content & dynamic pagination                    ║
║                                                                      ║
║  🎯 Perfect for: Sales teams, Market research, Lead generation      ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
    """
    print(banner)


def get_sample_urls():
    """Return sample URLs for Egyptian business directories"""
    return {
        'yellow_pages': [
            'https://www.yellowpages.com.eg/en/cairo/clothing',
            'https://www.yellowpages.com.eg/en/cairo/restaurants',
            'https://www.yellowpages.com.eg/en/cairo/pharmacies',
        ],
        'google_maps': [
            'https://www.google.com/maps/search/ملابس+القاهرة',
            'https://www.google.com/maps/search/مطاعم+الإسكندرية',
            'https://www.google.com/maps/search/صيدليات+الجيزة',
        ]
    }


def interactive_mode():
    """Interactive mode for user input"""
    print_banner()
    
    print("\n📋 EXTRACTION OPTIONS:")
    print("-" * 70)
    print("1. Enter custom URLs")
    print("2. Use sample Egyptian directory URLs")
    print("3. Generate Google Maps URLs by category")
    print("4. Exit")
    print("-" * 70)
    
    choice = input("\nSelect option (1-4): ").strip()
    
    urls = []
    
    if choice == '1':
        print("\n📝 Enter URLs (one per line, press Enter twice when done):")
        while True:
            line = input().strip()
            if not line:
                break
            urls.append(line)
    
    elif choice == '2':
        sample_urls = get_sample_urls()
        print("\n📚 Sample URLs:")
        all_samples = sample_urls['yellow_pages'] + sample_urls['google_maps']
        for i, url in enumerate(all_samples, 1):
            print(f"{i}. {url}")
        urls = all_samples
        
        use_samples = input("\nUse these URLs? (y/n): ").strip().lower()
        if use_samples != 'y':
            return []
    
    elif choice == '3':
        print("\n🗺️  Google Maps URL Generator")
        print("-" * 70)
        
        categories = input("Enter categories (Arabic, comma-separated)\nExample: ملابس,مطاعم,صيدليات\n> ").strip().split(',')
        cities = input("\nEnter cities (comma-separated)\nExample: القاهرة,الإسكندرية,الجيزة\n> ").strip().split(',')
        
        gmaps = GoogleMapsExtractor()
        urls = gmaps.generate_search_urls(
            [c.strip() for c in categories],
            [f"{c.strip()}, Egypt" for c in cities]
        )
        
        print(f"\n✅ Generated {len(urls)} URLs")
        for i, url in enumerate(urls, 1):
            print(f"{i}. {url}")
    
    else:
        return []
    
    return urls


def main():
    """Main execution function"""
    
    parser = argparse.ArgumentParser(
        description='Extract and analyze Egyptian shop data from web directories',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        '-u', '--urls',
        nargs='+',
        help='URLs to scrape'
    )
    
    parser.add_argument(
        '-f', '--file',
        help='File containing URLs (one per line)'
    )
    
    parser.add_argument(
        '-o', '--output',
        default='egyptian_shops_analyzed.xlsx',
        help='Output Excel file (default: egyptian_shops_analyzed.xlsx)'
    )
    
    parser.add_argument(
        '-p', '--pages',
        type=int,
        default=10,
        help='Max pages to scrape per URL (default: 10)'
    )
    
    parser.add_argument(
        '--no-ai',
        action='store_true',
        help='Skip AI analysis'
    )
    
    parser.add_argument(
        '-i', '--interactive',
        action='store_true',
        help='Run in interactive mode'
    )
    
    args = parser.parse_args()
    
    # Get URLs
    urls = []
    
    if args.interactive or (not args.urls and not args.file):
        urls = interactive_mode()
        if not urls:
            print("\n❌ No URLs provided. Exiting...")
            return
    
    elif args.file:
        with open(args.file, 'r', encoding='utf-8') as f:
            urls = [line.strip() for line in f if line.strip()]
    
    elif args.urls:
        urls = args.urls
    
    if not urls:
        print("\n❌ No URLs to process. Use -i for interactive mode or -h for help.")
        return
    
    # Print configuration
    print("\n" + "=" * 70)
    print("🚀 STARTING EXTRACTION")
    print("=" * 70)
    print(f"URLs to process: {len(urls)}")
    print(f"Max pages per URL: {args.pages}")
    print(f"Output file: {args.output}")
    print(f"AI analysis: {'Disabled' if args.no_ai else 'Enabled'}")
    print("=" * 70 + "\n")
    
    # Extract data
    extractor = ShopDataExtractor()
    df = extractor.scrape_multiple_urls(urls, max_pages_per_url=args.pages)
    
    if df.empty:
        print("\n❌ No data extracted. Please check your URLs and try again.")
        return
    
    # AI Analysis
    if not args.no_ai:
        print("\n" + "=" * 70)
        print("🤖 RUNNING AI ANALYSIS")
        print("=" * 70)
        
        analyzer = ShopAIAnalyzer()
        df = analyzer.analyze_dataframe(df)
        
        # Generate insights report
        report = analyzer.generate_insights_report(df)
        print("\n" + report)
        
        # Save report
        report_file = args.output.replace('.xlsx', '_report.txt')
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report)
        print(f"\n📄 Report saved to: {report_file}")
    
    # Export data
    print("\n" + "=" * 70)
    print("💾 EXPORTING DATA")
    print("=" * 70)
    
    extractor.clean_and_export(df, args.output)
    
    # Also export CSV
    csv_file = args.output.replace('.xlsx', '.csv')
    df.to_csv(csv_file, index=False, encoding='utf-8-sig')
    print(f"📊 CSV exported to: {csv_file}")
    
    # Summary
    print("\n" + "=" * 70)
    print("✅ EXTRACTION COMPLETE!")
    print("=" * 70)
    print(f"📈 Total shops: {len(df)}")
    print(f"📞 With phone: {df['phone'].notna().sum()}")
    print(f"📧 With email: {df['email'].notna().sum()}")
    print(f"📱 With social: {df[['instagram', 'facebook']].notna().any(axis=1).sum()}")
    
    if not args.no_ai:
        print(f"\n🎯 Revenue Distribution:")
        for rating, count in df['revenue_rating'].value_counts().items():
            print(f"   {rating}: {count} shops")
    
    print("\n" + "=" * 70)
    print("🎉 Files ready for your Sellfast SaaS!")
    print("=" * 70)


if __name__ == "__main__":
    main()
