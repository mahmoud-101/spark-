# 🛍️ Egyptian Business Data Extractor - Streamlit PWA

<div align="center">

![Version](https://img.shields.io/badge/version-2.0-blue)
![Python](https://img.shields.io/badge/python-3.8+-green)
![Streamlit](https://img.shields.io/badge/streamlit-1.28+-red)
![License](https://img.shields.io/badge/license-MIT-yellow)

**تطبيق ويب احترافي لاستخراج وتحليل بيانات الأعمال المصرية**

[English](#english) | [العربية](#arabic)

</div>

---

## <a name="english"></a>🇬🇧 English

### 🌟 Overview

A professional web application built with Streamlit for extracting and analyzing Egyptian business data from online directories. Works perfectly on mobile devices through PWA technology.

### ✨ Key Features

- **📊 Universal Extraction**: Extract data from shops, companies, clinics, schools, and any business type
- **🤖 AI Analysis**: Automatic categorization, revenue scoring, and lead quality assessment
- **📱 Mobile-First**: Responsive PWA design, works on any device
- **🇪🇬 Arabic Support**: Full RTL support with Arabic content handling
- **💾 Easy Export**: Download results as Excel or CSV instantly
- **☁️ Flexible Deployment**: Run locally or deploy to cloud for free

### 🚀 Quick Start

#### Local Installation

```bash
# Clone or extract the project
cd streamlit-shop-extractor

# Install dependencies
pip install -r requirements.txt

# Run the app
streamlit run app.py
```

Open browser at: `http://localhost:8501`

#### Cloud Deployment (Streamlit Cloud)

1. Upload to GitHub
2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Click "New app" and select your repository
4. Set main file to `app.py`
5. Deploy and get a public URL!

### 📱 Mobile Usage (Termux - Android)

```bash
# Install Termux from F-Droid or Google Play
pkg install python python-pip
cd ~/storage/downloads/streamlit-shop-extractor
bash start.sh
```

Open Chrome at: `http://localhost:8501`

### 📚 Documentation

- **README_STREAMLIT.md** - Complete application guide
- **MOBILE_GUIDE.md** - Mobile installation and usage
- **DEPLOYMENT.md** - Cloud deployment options
- **QUICK_START.md** - Quick start examples (Arabic)

### 🎯 Use Cases

- **Sales Teams**: Generate qualified leads with contact info
- **Market Research**: Analyze business distribution and trends
- **Business Development**: Build partner and supplier databases
- **CRM Integration**: Export clean data for CRM systems

### 📊 Extracted Data

- Business names (Arabic & English)
- Phone numbers (validated)
- Email addresses (validated)
- Physical addresses
- Social media (Instagram, Facebook, WhatsApp)
- Websites
- Products/Services
- AI categories and revenue scores

### 🔒 Legal & Ethics

- ✅ Extracts publicly available business information
- ✅ Respects robots.txt and rate limiting
- ✅ Suitable for legitimate business purposes
- ❌ Do NOT use for personal data harvesting or spam

### 📄 License

MIT License - Free for personal and commercial use

---

## <a name="arabic"></a>🇪🇬 العربية

### 🌟 نظرة عامة

تطبيق ويب احترافي مبني بـ Streamlit لاستخراج وتحليل بيانات الأعمال المصرية من الدلائل الإلكترونية. يعمل بشكل مثالي على الموبايل من خلال تقنية PWA.

### ✨ المميزات الرئيسية

- **📊 استخراج شامل**: استخرج بيانات المحلات، الشركات، العيادات، المدارس، وأي نشاط تجاري
- **🤖 تحليل ذكي**: تصنيف تلقائي، تقييم الإيرادات، وتقييم جودة العملاء المحتملين
- **📱 للموبايل أولاً**: تصميم PWA متجاوب، يعمل على أي جهاز
- **🇪🇬 دعم العربية**: دعم كامل للغة العربية مع RTL
- **💾 تصدير سهل**: حمّل النتائج كـ Excel أو CSV فوراً
- **☁️ نشر مرن**: شغّل محلياً أو انشر على Cloud مجاناً

### 🚀 البدء السريع

#### التثبيت المحلي

```bash
# استخرج أو استنسخ المشروع
cd streamlit-shop-extractor

# ثبّت المكتبات
pip install -r requirements.txt

# شغّل التطبيق
streamlit run app.py
```

افتح المتصفح على: `http://localhost:8501`

#### النشر على Cloud (Streamlit Cloud)

1. ارفع على GitHub
2. اذهب لـ [share.streamlit.io](https://share.streamlit.io)
3. اضغط "New app" واختر repository
4. اضبط الملف الرئيسي: `app.py`
5. انشر واحصل على رابط عام!

### 📱 الاستخدام على الموبايل (Termux - Android)

```bash
# ثبّت Termux من F-Droid أو Google Play
pkg install python python-pip
cd ~/storage/downloads/streamlit-shop-extractor
bash start.sh
```

افتح Chrome على: `http://localhost:8501`

### 📚 التوثيق

- **README_STREAMLIT.md** - دليل التطبيق الكامل (إنجليزي)
- **MOBILE_GUIDE.md** - التثبيت والاستخدام على الموبايل
- **DEPLOYMENT.md** - خيارات النشر على Cloud
- **QUICK_START.md** - أمثلة البدء السريع (عربي)

### 🎯 حالات الاستخدام

- **فرق المبيعات**: توليد عملاء محتملين مع بيانات الاتصال
- **أبحاث السوق**: تحليل توزيع الأعمال والاتجاهات
- **تطوير الأعمال**: بناء قواعد بيانات الشركاء والموردين
- **تكامل CRM**: تصدير بيانات نظيفة لأنظمة CRM

### 📊 البيانات المستخرجة

- أسماء الأعمال (عربي وإنجليزي)
- أرقام الهواتف (محققة)
- عناوين البريد الإلكتروني (محققة)
- العناوين الفعلية
- وسائل التواصل الاجتماعي (Instagram, Facebook, WhatsApp)
- المواقع الإلكترونية
- المنتجات/الخدمات
- فئات AI وتقييمات الإيرادات

### 🔒 القانون والأخلاقيات

- ✅ يستخرج معلومات الأعمال المتاحة للعامة
- ✅ يحترم robots.txt وحدود المعدل
- ✅ مناسب للأغراض التجارية المشروعة
- ❌ لا تستخدمه لجمع البيانات الشخصية أو الرسائل المزعجة

### 📄 الترخيص

ترخيص MIT - مجاني للاستخدام الشخصي والتجاري

---

## 📦 Project Structure

```
streamlit-shop-extractor/
├── app.py                      # Main Streamlit application
├── extractor.py                # Core extraction logic
├── ai_analyzer.py              # AI analysis module
├── google_maps_extractor.py    # Google Maps handler
├── playwright_extractor.py     # Dynamic content extractor
├── requirements.txt            # Python dependencies
├── start.sh                    # Quick start script
├── README.md                   # This file
├── README_STREAMLIT.md         # Full documentation
├── MOBILE_GUIDE.md            # Mobile guide
├── DEPLOYMENT.md              # Deployment guide
├── QUICK_START.md             # Quick start (Arabic)
├── index.html                 # Welcome page
├── sample_urls.txt            # Sample URLs for testing
└── .streamlit/
    └── config.toml            # Streamlit configuration
```

---

## 🎉 Getting Started

### Choose Your Method:

1. **💻 Local (Computer/Laptop)**
   ```bash
   bash start.sh
   # or
   streamlit run app.py
   ```

2. **📱 Mobile (Termux)**
   ```bash
   pkg install python python-pip
   bash start.sh
   ```

3. **☁️ Cloud (Streamlit Cloud)**
   - Upload to GitHub
   - Deploy at share.streamlit.io
   - Share URL with team

### Need Help?

- Read **README_STREAMLIT.md** for full documentation
- Check **MOBILE_GUIDE.md** for mobile setup
- Review **QUICK_START.md** for examples (Arabic)
- Test with sample URLs first

---

## 🌟 Star This Project

If you find this useful, please star the repository! ⭐

---

<div align="center">

**Made with ❤️ for Egyptian entrepreneurs**

**صنع بحب لرواد الأعمال المصريين**

🇪🇬 Egypt | مصر 🇪🇬

</div>
