#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Sellfast SaaS Integration Module
Ready-to-use template for integrating with Sellfast platform
"""

import pandas as pd
from typing import List, Dict, Optional
from datetime import datetime
import json

from extractor import ShopDataExtractor
from ai_analyzer import ShopAIAnalyzer


class SellfastLeadGenerator:
    """
    Lead generation module for Sellfast SaaS
    
    Features:
    - Extract Egyptian shop data from URLs
    - AI-powered categorization and scoring
    - Export in CRM-ready format
    - Lead quality filtering
    - Batch processing
    """
    
    def __init__(self):
        self.extractor = ShopDataExtractor()
        self.analyzer = ShopAIAnalyzer()
        self.leads_data = pd.DataFrame()
    
    def extract_leads(
        self, 
        urls: List[str], 
        max_pages: int = 10,
        min_quality_score: int = 25
    ) -> pd.DataFrame:
        """
        Extract leads from URLs
        
        Args:
            urls: List of URLs to scrape
            max_pages: Max pages per URL
            min_quality_score: Minimum revenue score (0-100)
        
        Returns:
            DataFrame with extracted and analyzed leads
        """
        print(f"🚀 Extracting leads from {len(urls)} URL(s)...")
        
        # Extract data
        df = self.extractor.scrape_multiple_urls(urls, max_pages_per_url=max_pages)
        
        if df.empty:
            print("❌ No data extracted")
            return df
        
        print(f"✅ Extracted {len(df)} raw leads")
        
        # AI Analysis
        print("🤖 Running AI analysis...")
        df = self.analyzer.analyze_dataframe(df)
        
        # Filter by quality
        df = df[df['revenue_score'] >= min_quality_score]
        print(f"✅ {len(df)} leads meet quality threshold (>={min_quality_score})")
        
        self.leads_data = df
        return df
    
    def enrich_for_crm(self, df: pd.DataFrame = None) -> pd.DataFrame:
        """
        Enrich data with CRM-specific fields
        
        Adds:
        - lead_status
        - lead_source
        - priority
        - assigned_to
        - follow_up_date
        - notes
        """
        if df is None:
            df = self.leads_data.copy()
        
        # Add CRM fields
        df['lead_status'] = 'New'
        df['lead_source'] = 'Web Scraping'
        df['created_date'] = datetime.now().strftime('%Y-%m-%d')
        df['assigned_to'] = ''
        df['follow_up_date'] = ''
        
        # Priority based on revenue rating
        priority_map = {
            'High': 'Hot 🔥',
            'Medium-High': 'Warm ⭐',
            'Medium': 'Cold ❄️',
            'Low': 'Archive 📦'
        }
        df['priority'] = df['revenue_rating'].map(priority_map)
        
        # Generate notes
        def generate_notes(row):
            notes = []
            if row.get('website'):
                notes.append(f"Has website: {row['website']}")
            if row.get('instagram'):
                notes.append(f"Instagram: {row['instagram']}")
            if row.get('facebook'):
                notes.append(f"Facebook: {row['facebook']}")
            return ' | '.join(notes)
        
        df['notes'] = df.apply(generate_notes, axis=1)
        
        return df
    
    def export_for_sellfast(
        self, 
        output_file: str = 'sellfast_leads.xlsx',
        format: str = 'excel'
    ) -> str:
        """
        Export leads in Sellfast-compatible format
        
        Args:
            output_file: Output filename
            format: 'excel', 'csv', or 'json'
        
        Returns:
            Path to exported file
        """
        if self.leads_data.empty:
            print("❌ No leads data to export")
            return None
        
        # Enrich data
        df = self.enrich_for_crm()
        
        # Select and reorder columns for CRM
        crm_columns = [
            'shop_name',
            'phone',
            'whatsapp',
            'email',
            'address',
            'ai_category',
            'revenue_score',
            'revenue_rating',
            'priority',
            'lead_status',
            'lead_source',
            'created_date',
            'assigned_to',
            'follow_up_date',
            'instagram',
            'facebook',
            'website',
            'products',
            'notes'
        ]
        
        # Keep only available columns
        available_cols = [col for col in crm_columns if col in df.columns]
        df_export = df[available_cols]
        
        # Export
        if format == 'excel':
            df_export.to_excel(output_file, index=False)
        elif format == 'csv':
            df_export.to_csv(output_file, index=False, encoding='utf-8-sig')
        elif format == 'json':
            df_export.to_json(output_file, orient='records', force_ascii=False, indent=2)
        
        print(f"✅ Exported {len(df_export)} leads to {output_file}")
        return output_file
    
    def get_statistics(self) -> Dict:
        """Get lead statistics"""
        if self.leads_data.empty:
            return {}
        
        df = self.leads_data
        
        stats = {
            'total_leads': len(df),
            'high_priority': len(df[df['revenue_rating'] == 'High']),
            'with_email': df['email'].notna().sum(),
            'with_phone': df['phone'].notna().sum(),
            'with_social': df[['instagram', 'facebook']].notna().any(axis=1).sum(),
            'with_website': df['website'].notna().sum(),
            'categories': df['ai_category'].value_counts().to_dict(),
            'avg_revenue_score': df['revenue_score'].mean()
        }
        
        return stats
    
    def filter_by_category(self, category: str) -> pd.DataFrame:
        """Filter leads by category"""
        return self.leads_data[self.leads_data['ai_category'] == category]
    
    def filter_by_location(self, location: str) -> pd.DataFrame:
        """Filter leads by location keyword in address"""
        return self.leads_data[
            self.leads_data['address'].str.contains(location, case=False, na=False)
        ]
    
    def get_top_leads(self, n: int = 50) -> pd.DataFrame:
        """Get top N leads by revenue score"""
        return self.leads_data.nlargest(n, 'revenue_score')


# Example usage for Sellfast SaaS
def sellfast_integration_example():
    """
    Example integration with Sellfast SaaS platform
    """
    
    print("""
╔════════════════════════════════════════════════════════════════╗
║                                                                ║
║           SELLFAST SAAS INTEGRATION EXAMPLE                   ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝
    """)
    
    # Initialize
    lead_gen = SellfastLeadGenerator()
    
    # Example URLs (replace with real URLs)
    urls = [
        'https://www.yellowpages.com.eg/en/cairo/clothing',
        'https://www.yellowpages.com.eg/en/cairo/restaurants',
    ]
    
    # Extract leads
    leads = lead_gen.extract_leads(
        urls=urls,
        max_pages=5,
        min_quality_score=40  # Only medium+ quality leads
    )
    
    if leads.empty:
        print("No leads found. Try different URLs.")
        return
    
    # Get statistics
    stats = lead_gen.get_statistics()
    print("\n📊 LEAD STATISTICS:")
    print(f"  Total Leads: {stats['total_leads']}")
    print(f"  High Priority: {stats['high_priority']}")
    print(f"  With Email: {stats['with_email']}")
    print(f"  With Phone: {stats['with_phone']}")
    print(f"  Avg Score: {stats['avg_revenue_score']:.1f}")
    
    # Filter examples
    print("\n🔍 FILTERING EXAMPLES:")
    
    # Top 10 leads
    top_10 = lead_gen.get_top_leads(10)
    print(f"\nTop 10 Leads:")
    print(top_10[['shop_name', 'revenue_score', 'ai_category']].to_string())
    
    # Filter by category
    clothing_leads = lead_gen.filter_by_category('clothing')
    print(f"\n👔 Clothing stores: {len(clothing_leads)}")
    
    # Filter by location
    cairo_leads = lead_gen.filter_by_location('القاهرة')
    print(f"\n📍 Cairo shops: {len(cairo_leads)}")
    
    # Export for Sellfast
    print("\n📤 EXPORTING...")
    
    # Excel format
    lead_gen.export_for_sellfast('sellfast_leads.xlsx', format='excel')
    
    # CSV format (for bulk import)
    lead_gen.export_for_sellfast('sellfast_leads.csv', format='csv')
    
    # JSON format (for API integration)
    lead_gen.export_for_sellfast('sellfast_leads.json', format='json')
    
    print("\n✅ INTEGRATION COMPLETE!")
    print("Files ready for Sellfast CRM import")


if __name__ == "__main__":
    # For production use:
    # 1. Replace example URLs with real Egyptian business directories
    # 2. Adjust quality thresholds based on your needs
    # 3. Schedule regular extractions (cron jobs)
    # 4. Integrate with Sellfast API for automatic import
    
    sellfast_integration_example()
