#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Playwright-based Web Scraper for Dynamic Content
Handles JavaScript-rendered pages like Google Maps
"""

import asyncio
import json
import re
from typing import List, Dict
from playwright.async_api import async_playwright, Page, Browser
import logging

logger = logging.getLogger(__name__)


class PlaywrightExtractor:
    """Extract data from JavaScript-heavy websites using Playwright"""
    
    def __init__(self):
        self.browser: Browser = None
        self.context = None
    
    async def init_browser(self):
        """Initialize Playwright browser"""
        playwright = await async_playwright().start()
        self.browser = await playwright.chromium.launch(
            headless=True,
            args=['--disable-blink-features=AutomationControlled']
        )
        self.context = await self.browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        )
    
    async def close_browser(self):
        """Close browser"""
        if self.context:
            await self.context.close()
        if self.browser:
            await self.browser.close()
    
    async def extract_google_maps_shops(self, search_url: str, max_results: int = 100) -> List[Dict]:
        """Extract shop data from Google Maps search results"""
        
        shops = []
        
        try:
            page = await self.context.new_page()
            
            logger.info(f"Loading Google Maps: {search_url}")
            await page.goto(search_url, wait_until='networkidle', timeout=60000)
            
            # Wait for results to load
            await page.wait_for_selector('[role="article"]', timeout=30000)
            await asyncio.sleep(3)
            
            # Scroll to load more results
            results_panel = await page.query_selector('[role="feed"]')
            if results_panel:
                for _ in range(10):  # Scroll 10 times to load more
                    await page.evaluate('document.querySelector(\'[role="feed"]\').scrollBy(0, 1000)')
                    await asyncio.sleep(2)
            
            # Extract business listings
            listings = await page.query_selector_all('[role="article"]')
            logger.info(f"Found {len(listings)} listings")
            
            for listing in listings[:max_results]:
                try:
                    shop_data = await self.extract_single_google_maps_shop(listing, page)
                    if shop_data and shop_data.get('name'):
                        shops.append(shop_data)
                except Exception as e:
                    logger.error(f"Error extracting listing: {e}")
                    continue
            
            await page.close()
            
        except Exception as e:
            logger.error(f"Error scraping Google Maps: {e}")
        
        return shops
    
    async def extract_single_google_maps_shop(self, listing, page: Page) -> Dict:
        """Extract data from a single Google Maps listing"""
        
        shop_data = {
            'name': '',
            'phone': '',
            'address': '',
            'website': '',
            'rating': '',
            'reviews_count': '',
            'category': '',
            'hours': '',
            'plus_code': ''
        }
        
        try:
            # Click to open details
            await listing.click()
            await asyncio.sleep(2)
            
            # Extract name
            name_elem = await page.query_selector('h1')
            if name_elem:
                shop_data['name'] = await name_elem.inner_text()
            
            # Extract rating and reviews
            rating_elem = await page.query_selector('[role="img"][aria-label*="star"]')
            if rating_elem:
                aria_label = await rating_elem.get_attribute('aria-label')
                rating_match = re.search(r'(\d+\.?\d*)\s*star', aria_label)
                if rating_match:
                    shop_data['rating'] = rating_match.group(1)
                
                reviews_match = re.search(r'(\d+,?\d*)\s*review', aria_label)
                if reviews_match:
                    shop_data['reviews_count'] = reviews_match.group(1)
            
            # Extract phone
            phone_button = await page.query_selector('[data-tooltip="Copy phone number"]')
            if phone_button:
                shop_data['phone'] = await phone_button.inner_text()
            
            # Extract address
            address_button = await page.query_selector('[data-tooltip="Copy address"]')
            if address_button:
                shop_data['address'] = await address_button.inner_text()
            
            # Extract website
            website_link = await page.query_selector('a[data-tooltip="Open website"]')
            if website_link:
                shop_data['website'] = await website_link.get_attribute('href')
            
            # Extract category
            category_button = await page.query_selector('button[jsaction*="category"]')
            if category_button:
                shop_data['category'] = await category_button.inner_text()
            
        except Exception as e:
            logger.error(f"Error extracting shop details: {e}")
        
        return shop_data
    
    async def extract_yellow_pages_egypt(self, url: str, max_pages: int = 10) -> List[Dict]:
        """Extract from Yellow Pages Egypt"""
        
        shops = []
        
        try:
            page = await self.context.new_page()
            
            for page_num in range(1, max_pages + 1):
                logger.info(f"Scraping Yellow Pages page {page_num}")
                
                current_url = url if page_num == 1 else f"{url}?page={page_num}"
                await page.goto(current_url, wait_until='networkidle')
                await asyncio.sleep(2)
                
                # Extract listings
                listings = await page.query_selector_all('.listing-item, .business-item, .result-item')
                
                if not listings:
                    logger.info("No more listings found")
                    break
                
                for listing in listings:
                    try:
                        shop_data = {
                            'name': '',
                            'phone': '',
                            'address': '',
                            'website': '',
                            'category': ''
                        }
                        
                        # Extract name
                        name_elem = await listing.query_selector('h2, h3, .name, .title')
                        if name_elem:
                            shop_data['name'] = await name_elem.inner_text()
                        
                        # Extract phone
                        phone_elem = await listing.query_selector('.phone, [href^="tel:"]')
                        if phone_elem:
                            shop_data['phone'] = await phone_elem.inner_text()
                        
                        # Extract address
                        address_elem = await listing.query_selector('.address, .location')
                        if address_elem:
                            shop_data['address'] = await address_elem.inner_text()
                        
                        # Extract website
                        website_elem = await listing.query_selector('a[href^="http"]')
                        if website_elem:
                            shop_data['website'] = await website_elem.get_attribute('href')
                        
                        if shop_data['name']:
                            shops.append(shop_data)
                    
                    except Exception as e:
                        logger.error(f"Error extracting Yellow Pages listing: {e}")
                        continue
                
                # Check for next page
                next_button = await page.query_selector('a.next, .pagination .next, [aria-label="Next"]')
                if not next_button:
                    break
            
            await page.close()
            
        except Exception as e:
            logger.error(f"Error scraping Yellow Pages: {e}")
        
        return shops


async def main():
    """Demo Playwright extractor"""
    
    print("🎭 Playwright Web Extractor for Egyptian Shops")
    print("=" * 70)
    print("\nThis extractor handles JavaScript-rendered websites like Google Maps")
    print("\nNote: First run will download Chromium browser (~100MB)")
    print("\n" + "=" * 70)
    
    extractor = PlaywrightExtractor()
    
    try:
        await extractor.init_browser()
        
        # Example: Google Maps search
        search_url = "https://www.google.com/maps/search/ملابس+القاهرة"
        
        print(f"\n🔍 Searching Google Maps: ملابس القاهرة")
        shops = await extractor.extract_google_maps_shops(search_url, max_results=20)
        
        print(f"\n✅ Extracted {len(shops)} shops")
        
        if shops:
            print("\nSample results:")
            for i, shop in enumerate(shops[:5], 1):
                print(f"\n{i}. {shop['name']}")
                print(f"   Phone: {shop.get('phone', 'N/A')}")
                print(f"   Address: {shop.get('address', 'N/A')}")
                print(f"   Rating: {shop.get('rating', 'N/A')} ({shop.get('reviews_count', '0')} reviews)")
        
    finally:
        await extractor.close_browser()


if __name__ == "__main__":
    asyncio.run(main())
