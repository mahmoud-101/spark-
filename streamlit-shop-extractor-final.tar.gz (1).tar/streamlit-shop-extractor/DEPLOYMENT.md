# Egyptian Business Extractor - Streamlit Cloud Deployment

## Quick Deploy to Streamlit Cloud

### Step 1: Prepare Repository

1. Create new GitHub repository
2. Upload these files:
   - app.py
   - requirements.txt
   - All .py files (extractor.py, ai_analyzer.py, etc.)
   - .streamlit/config.toml
   - README_STREAMLIT.md

### Step 2: Deploy

1. Go to: https://share.streamlit.io
2. Click "New app"
3. Connect GitHub account
4. Select repository
5. Set:
   - Main file: `app.py`
   - Python version: 3.9+
6. Click "Deploy"

### Step 3: Configure (Optional)

Add to your repository a `secrets.toml` file in `.streamlit/` folder:

```toml
# .streamlit/secrets.toml
# Add any API keys or secrets here
# Example:
# api_key = "your-key-here"
```

### Environment Variables

No special environment variables needed. App is ready to deploy!

### Custom Domain (Optional)

1. Go to app settings in Streamlit Cloud
2. Add custom domain
3. Configure DNS records

### Limitations (Free Tier)

- 1 GB RAM
- 1 CPU
- Public apps only (unless on Team/Enterprise plan)
- 1000 views per month (soft limit)

### Tips for Free Tier

1. Optimize data loading
2. Use caching effectively
3. Limit concurrent extractions
4. Consider upgrading for production use

---

## Alternative: Deploy to Heroku

### Step 1: Create Procfile

```bash
web: streamlit run app.py --server.port $PORT --server.enableCORS false
```

### Step 2: Create runtime.txt

```
python-3.9.16
```

### Step 3: Deploy

```bash
heroku login
heroku create your-app-name
git push heroku main
```

---

## Alternative: Deploy to Railway

1. Connect GitHub repository
2. Select "Python" template
3. Auto-deploy enabled
4. Get public URL

---

## Cost Comparison

| Platform | Free Tier | Paid Tier |
|----------|-----------|-----------|
| Streamlit Cloud | 1 app | $20/mo (3 apps) |
| Heroku | Deprecated | $5-25/mo |
| Railway | $5 credit | Pay as you go |
| Render | 750 hours | $7-25/mo |
| PythonAnywhere | 1 app | $5/mo |

**Recommendation:** Start with Streamlit Cloud (easiest) or Railway (most flexible)
