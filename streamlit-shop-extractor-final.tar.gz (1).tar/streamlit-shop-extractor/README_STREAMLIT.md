# 🛍️ Egyptian Business Data Extractor - Streamlit PWA

<div dir="rtl">

## 📱 تطبيق ويب لاستخراج بيانات الأعمال المصرية

تطبيق احترافي يعمل من المتصفح مباشرة لاستخراج وتحليل بيانات:
- 🏪 المحلات والأزياء
- 🍔 المطاعم والكافيهات
- 🏢 الشركات والمؤسسات
- 🏥 العيادات والصيدليات
- 🎓 المدارس ومراكز التدريب
- 🔧 مكاتب الخدمات المهنية
- **وأي نشاط تجاري آخر!**

</div>

---

## ✨ Features / المميزات

### 📊 Data Extraction
- ✅ **Universal extraction** - Not just shops! Works with any business type
- ✅ Complete contact info (phone, email, WhatsApp)
- ✅ Social media profiles (Instagram, Facebook)
- ✅ Physical addresses and locations
- ✅ Business descriptions and services
- ✅ Multiple source support (Yellow Pages, Google Maps, any directory)

### 🤖 AI Analysis
- 🏷️ Automatic categorization
- 💰 Revenue potential scoring
- 📈 Lead quality assessment
- 📊 Business insights & recommendations

### 💻 User Interface
- 📱 **Mobile-friendly PWA** - Works perfectly on phones!
- 🌐 **Works in browser** - No installation needed
- 🇪🇬 **Arabic support** - Full RTL support
- 🎨 **Modern design** - Clean and intuitive
- 📤 **Easy export** - Download Excel/CSV instantly

### 🚀 Flexible Deployment
- 💻 **Local** - Run on your device/phone
- ☁️ **Cloud** - Deploy to Streamlit Cloud (free)
- 👥 **Team access** - Perfect for 2-5 users

---

## 🚀 Quick Start / البدء السريع

### Option 1: Local (Your Computer/Phone)

#### Prerequisites
- Python 3.8 or higher
- Internet connection

#### Installation

```bash
# 1. Install Python (if not already installed)
# Download from: https://www.python.org/downloads/

# 2. Navigate to project directory
cd streamlit-shop-extractor

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the app
streamlit run app.py
```

The app will open automatically at `http://localhost:8501`

#### For Android/Mobile (Termux)

```bash
# 1. Install Termux from F-Droid or Google Play

# 2. Install Python in Termux
pkg install python
pkg install python-pip

# 3. Navigate to project folder
cd storage/downloads/streamlit-shop-extractor

# 4. Install dependencies
pip install -r requirements.txt

# 5. Run the app
streamlit run app.py --server.headless true
```

Access from phone browser at `http://localhost:8501`

---

### Option 2: Cloud Deployment (Streamlit Community Cloud)

**Best for team access and no local setup!**

#### Steps:

1. **Upload project to GitHub:**
   ```bash
   # Create new repository on GitHub
   # Upload all files from streamlit-shop-extractor folder
   ```

2. **Deploy to Streamlit Cloud:**
   - Go to [share.streamlit.io](https://share.streamlit.io)
   - Sign in with GitHub
   - Click "New app"
   - Select your repository
   - Set main file: `app.py`
   - Click "Deploy"

3. **Access your app:**
   - Get a URL like: `https://your-app-name.streamlit.app`
   - Share with team members
   - Works on any device!

**Benefits:**
- ✅ Free hosting
- ✅ Always online
- ✅ Automatic updates
- ✅ No maintenance
- ✅ Perfect for teams

---

### Option 3: Deploy to Other Platforms

#### Heroku
```bash
# Add Procfile
echo "web: streamlit run app.py --server.port $PORT" > Procfile

# Deploy
heroku create your-app-name
git push heroku main
```

#### Railway.app
- Connect GitHub repository
- Select Python
- Auto-detect and deploy

#### Render.com
- New Web Service
- Connect GitHub
- Build command: `pip install -r requirements.txt`
- Start command: `streamlit run app.py`

---

## 📖 How to Use / طريقة الاستخدام

### 1️⃣ Choose Input Method

**A. Manual URLs**
- Enter URLs directly (one per line)
- Supports any business directory

**B. Sample URLs**
- Select from pre-configured Egyptian sources
- Covers multiple business categories

**C. Generate Google Maps URLs**
- Enter categories (e.g., محلات، مطاعم، شركات)
- Enter cities (e.g., القاهرة، الإسكندرية)
- Auto-generate search URLs

### 2️⃣ Configure Settings

- **Max Pages**: How many pages to extract per URL
- **AI Analysis**: Enable/disable AI features
- **Business Types**: Filter by specific categories

### 3️⃣ Extract & Analyze

- Click "Start Extraction"
- Wait for processing (shows progress)
- View results in real-time

### 4️⃣ Review & Export

- Filter and search results
- View AI analysis and insights
- Download Excel or CSV

---

## 🎯 Use Cases / حالات الاستخدام

### 1️⃣ Sales & Lead Generation
- Extract qualified business leads
- Get complete contact information
- Revenue scoring for prioritization

### 2️⃣ Market Research
- Analyze business distribution
- Identify market gaps
- Track competition

### 3️⃣ Business Development
- Build partner databases
- Find suppliers/vendors
- Discover collaboration opportunities

### 4️⃣ CRM & Marketing
- Import leads into CRM systems
- Create targeted marketing lists
- Build customer databases

---

## 📊 Data Fields Extracted / البيانات المستخرجة

| Field | Description | Example |
|-------|-------------|---------|
| shop_name | Business name | محل الأزياء العصرية |
| phone | Phone number(s) | +201234567890 |
| whatsapp | WhatsApp link | wa.me/201234567890 |
| email | Email address | info@business.com |
| address | Physical address | شارع التحرير، القاهرة |
| instagram | Instagram handle | @businessname |
| facebook | Facebook URL | facebook.com/business |
| website | Website URL | www.business.com |
| products | Products/Services | ملابس، أحذية |
| ai_category | AI category | clothing |
| revenue_score | Revenue score (0-100) | 85 |
| revenue_rating | Revenue rating | High 🔥 |

---

## 🎨 Screenshots / لقطات الشاشة

### Main Interface
- Clean, modern design
- Mobile-responsive layout
- Easy navigation

### Extraction Process
- Real-time progress tracking
- Clear status messages
- Error handling

### Results View
- Sortable, filterable tables
- Statistics cards
- Export options

### Analysis Dashboard
- Category distribution charts
- Revenue analysis
- Key insights

---

## 🔧 Advanced Configuration / الإعدادات المتقدمة

### Customizing Categories

Edit `app.py` to add your own business categories:

```python
business_types = st.multiselect(
    "Select business types:",
    [
        "محلات (Shops)",
        "مطاعم (Restaurants)",
        # Add your custom categories here
        "مصانع (Factories)",
        "ورش (Workshops)",
        "Your Category"
    ]
)
```

### Adding Custom Sources

Add your URLs to `get_sample_urls()` function:

```python
def get_sample_urls():
    return {
        "Your Category": [
            "https://your-custom-source.com/businesses",
            "https://another-directory.com/listings",
        ],
        # ... other categories
    }
```

### Modifying AI Analysis

Edit `ai_analyzer.py` to customize:
- Scoring algorithms
- Categories
- Analysis rules

---

## 📱 Mobile App Installation (PWA)

### Android

1. Open app URL in Chrome
2. Click menu (⋮)
3. Select "Install app" or "Add to Home screen"
4. Use like native app!

### iOS

1. Open app URL in Safari
2. Tap Share button
3. Select "Add to Home Screen"
4. App appears on home screen

**Benefits:**
- ✅ Works offline (cached data)
- ✅ Full-screen experience
- ✅ App icon on home screen
- ✅ Fast loading

---

## 🔒 Security & Privacy

### Data Handling
- ✅ All data processed locally or in your cloud
- ✅ No data sent to third parties
- ✅ You control your data storage
- ✅ Can run completely offline

### Ethical Scraping
- ⚠️ Respects robots.txt
- ⚠️ Rate limiting implemented
- ⚠️ Only public business information
- ⚠️ Complies with terms of service

### Recommendations
- ✅ Use for legitimate business purposes
- ✅ Respect privacy and data protection laws
- ✅ Don't spam extracted contacts
- ✅ Follow local regulations

---

## 🐛 Troubleshooting / حل المشاكل

### App won't start
```bash
# Reinstall dependencies
pip install --upgrade -r requirements.txt

# Clear cache
streamlit cache clear
```

### No data extracted
- Check URL is accessible
- Verify internet connection
- Try with sample URLs first
- Check if site requires JavaScript (use Playwright)

### Arabic text appears broken
- Ensure UTF-8 encoding
- Check Excel opens with correct encoding
- Use Excel's "Data > From Text" import

### Slow extraction
- Reduce max_pages setting
- Process fewer URLs at once
- Check internet speed
- Use faster source (Yellow Pages vs Google Maps)

### Mobile display issues
- Clear browser cache
- Try different browser
- Check screen rotation
- Update Streamlit: `pip install --upgrade streamlit`

---

## 🚀 Performance Tips / نصائح الأداء

1. **Batch Processing**
   - Process 5-10 URLs at a time
   - Use reasonable max_pages (5-10)

2. **Source Selection**
   - Yellow Pages: Fast, reliable
   - Google Maps: Slower, needs Playwright
   - Start with simple sources

3. **Resource Management**
   - Close browser tabs after extraction
   - Clear cache periodically
   - Monitor memory usage

4. **Network Optimization**
   - Use stable internet connection
   - Avoid VPN if causing slowness
   - Consider off-peak hours

---

## 📞 Support / الدعم

### Common Questions

**Q: Can I extract from international sources?**
A: Yes! Works with any business directory worldwide.

**Q: How many businesses can I extract?**
A: Unlimited! Depends on source pages available.

**Q: Does it work without AI analysis?**
A: Yes, AI is optional. Disable in settings.

**Q: Can I run this on shared hosting?**
A: Best on Streamlit Cloud or VPS with Python support.

**Q: Is it free?**
A: Yes! Completely free and open source.

### Need Help?

1. Check troubleshooting section above
2. Review extraction logs
3. Test with sample URLs
4. Check requirements are installed

---

## 🎯 Roadmap / الخطة المستقبلية

### Planned Features

- [ ] Real-time extraction monitoring
- [ ] Email verification service
- [ ] Phone validation service
- [ ] Database storage (PostgreSQL/MongoDB)
- [ ] Scheduled extractions (cron)
- [ ] API endpoints for integration
- [ ] Multi-language support (more languages)
- [ ] Advanced filters and search
- [ ] Duplicate detection improvements
- [ ] Export to more formats (JSON, SQL)
- [ ] User authentication
- [ ] Team collaboration features

### Coming Soon

- 📊 Advanced analytics dashboard
- 🔔 Real-time notifications
- 💾 Cloud storage integration
- 🔌 CRM integrations (Salesforce, HubSpot)
- 📱 Native mobile apps (Flutter)

---

## 📄 Project Structure

```
streamlit-shop-extractor/
├── app.py                      # Main Streamlit application
├── extractor.py                # Core extraction logic
├── ai_analyzer.py              # AI analysis module
├── google_maps_extractor.py    # Google Maps handler
├── playwright_extractor.py     # Dynamic content extractor
├── requirements.txt            # Python dependencies
├── README.md                   # This file
├── .streamlit/
│   └── config.toml            # Streamlit configuration
└── sample_data/
    └── urls.txt               # Sample URLs for testing
```

---

## 🌟 Contributing

Contributions welcome! This is a community project.

### How to Contribute

1. Fork the repository
2. Create your feature branch
3. Make your changes
4. Test thoroughly
5. Submit pull request

### Areas for Contribution

- 🐛 Bug fixes
- ✨ New features
- 📖 Documentation improvements
- 🌍 Translations
- 🎨 UI/UX enhancements

---

## 📜 License

MIT License - Free for personal and commercial use

You are free to:
- ✅ Use commercially
- ✅ Modify
- ✅ Distribute
- ✅ Sublicense

---

## 👨‍💻 Credits

**Built for Egyptian entrepreneurs and sales teams**

Special thanks to:
- Python community
- Streamlit team
- Open source contributors

---

## 🎉 Success Stories

*"Extracted 500+ qualified leads in 30 minutes!"*
- Sales Team Lead, Cairo

*"Perfect for our market research. Clean data, great analysis."*
- Business Analyst, Alexandria

*"Works flawlessly on mobile. Team loves it!"*
- Startup Founder, Giza

---

<div dir="rtl">

## 🇪🇬 للمطورين المصريين

هذا المشروع مبني خصيصاً للسوق المصري:
- ✅ دعم كامل للغة العربية
- ✅ يعمل مع المصادر المصرية
- ✅ تحليل ذكي للبيانات المحلية
- ✅ سهل الاستخدام على الموبايل

**استخدمه في:**
- توليد العملاء المحتملين
- أبحاث السوق
- بناء قواعد البيانات
- التسويق الرقمي

</div>

---

**Made with ❤️ for Egyptian entrepreneurs | صنع بحب لرواد الأعمال المصريين**

🌟 If you find this useful, star the project!
