#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
🛍️ Egyptian Business Data Extractor - Streamlit App
تطبيق ويب لاستخراج بيانات الأعمال المصرية

Features:
- Extract shops, companies, offices, clinics, schools, and any business
- AI-powered analysis and categorization
- Export to Excel/CSV
- Mobile-friendly PWA interface
"""

import streamlit as st
import pandas as pd
import sys
import os
from pathlib import Path
import io
from datetime import datetime
import re

# Set page config (must be first Streamlit command)
st.set_page_config(
    page_title="🛍️ Egyptian Business Extractor",
    page_icon="🛍️",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        'Get Help': None,
        'Report a bug': None,
        'About': "# Egyptian Business Data Extractor\nاستخراج بيانات الأعمال المصرية"
    }
)

# Import local modules
try:
    from extractor import ShopDataExtractor
    from ai_analyzer import ShopAIAnalyzer
    from google_maps_extractor import GoogleMapsExtractor
except ImportError:
    st.error("⚠️ Missing required modules. Make sure all files are in the same directory.")
    st.stop()

# Custom CSS for better mobile experience
st.markdown("""
<style>
    /* RTL Support for Arabic */
    .rtl { direction: rtl; text-align: right; }
    
    /* Compact mobile layout */
    .stButton>button {
        width: 100%;
        border-radius: 8px;
        padding: 0.5rem 1rem;
        font-weight: 600;
    }
    
    /* Card-like containers */
    .stats-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1.5rem;
        border-radius: 12px;
        color: white;
        margin: 0.5rem 0;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    
    .stats-number {
        font-size: 2.5rem;
        font-weight: 700;
        margin: 0;
    }
    
    .stats-label {
        font-size: 0.9rem;
        opacity: 0.9;
        margin: 0;
    }
    
    /* Better data display */
    .stDataFrame {
        border-radius: 8px;
        overflow: hidden;
    }
    
    /* Progress indicators */
    .stProgress > div > div {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
    }
    
    /* Alerts styling */
    .stAlert {
        border-radius: 8px;
        padding: 1rem;
    }
</style>
""", unsafe_allow_html=True)

# Session state initialization
if 'extracted_data' not in st.session_state:
    st.session_state.extracted_data = None
if 'analyzed_data' not in st.session_state:
    st.session_state.analyzed_data = None
if 'extraction_complete' not in st.session_state:
    st.session_state.extraction_complete = False

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def get_sample_urls():
    """Return categorized sample URLs"""
    return {
        "محلات وأزياء (Shops & Fashion)": [
            "https://www.yellowpages.com.eg/en/cairo/clothing",
            "https://www.google.com/maps/search/محلات+ملابس+القاهرة",
        ],
        "مطاعم وكافيهات (Restaurants & Cafes)": [
            "https://www.yellowpages.com.eg/en/cairo/restaurants",
            "https://www.google.com/maps/search/مطاعم+الإسكندرية",
        ],
        "صيدليات ومراكز طبية (Pharmacies & Medical)": [
            "https://www.yellowpages.com.eg/en/cairo/pharmacies",
            "https://www.google.com/maps/search/عيادات+الجيزة",
        ],
        "شركات ومكاتب (Companies & Offices)": [
            "https://www.yellowpages.com.eg/en/cairo/software-companies",
            "https://www.google.com/maps/search/شركات+برمجة+القاهرة",
        ],
        "تعليم ومدارس (Education & Schools)": [
            "https://www.yellowpages.com.eg/en/cairo/schools",
            "https://www.google.com/maps/search/مراكز+تدريب+القاهرة",
        ],
    }

def format_dataframe_for_display(df):
    """Format dataframe for better display"""
    if df is None or df.empty:
        return df
    
    # Create a copy
    display_df = df.copy()
    
    # Truncate long text
    for col in display_df.columns:
        if display_df[col].dtype == 'object':
            display_df[col] = display_df[col].apply(
                lambda x: str(x)[:50] + '...' if isinstance(x, str) and len(str(x)) > 50 else x
            )
    
    return display_df

def export_to_excel(df, filename="egyptian_businesses.xlsx"):
    """Export dataframe to Excel in memory"""
    output = io.BytesIO()
    
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Businesses')
        
        # Auto-adjust column widths
        worksheet = writer.sheets['Businesses']
        for idx, col in enumerate(df.columns):
            max_length = max(
                df[col].astype(str).apply(len).max(),
                len(col)
            )
            worksheet.column_dimensions[chr(65 + idx)].width = min(max_length + 2, 50)
    
    output.seek(0)
    return output

# ============================================================================
# MAIN APP
# ============================================================================

def main():
    # Header
    st.markdown("<h1 style='text-align: center;'>🛍️ Egyptian Business Data Extractor</h1>", unsafe_allow_html=True)
    st.markdown("<p style='text-align: center; font-size: 1.2rem;' class='rtl'>أداة احترافية لاستخراج بيانات الأعمال المصرية</p>", unsafe_allow_html=True)
    
    st.markdown("---")
    
    # Sidebar configuration
    with st.sidebar:
        st.header("⚙️ Settings / الإعدادات")
        
        # Extraction settings
        st.subheader("📊 Extraction Settings")
        max_pages = st.slider(
            "Max pages per URL",
            min_value=1,
            max_value=20,
            value=10,
            help="عدد الصفحات المراد استخراجها من كل رابط"
        )
        
        enable_ai = st.checkbox(
            "🤖 Enable AI Analysis",
            value=True,
            help="تفعيل التحليل الذكي للبيانات"
        )
        
        st.markdown("---")
        
        # Business type selector
        st.subheader("🎯 Business Type / نوع النشاط")
        business_types = st.multiselect(
            "Select business types to focus on:",
            [
                "محلات (Shops)",
                "مطاعم (Restaurants)",
                "شركات (Companies)",
                "عيادات (Clinics)",
                "مدارس (Schools)",
                "مكاتب خدمات (Service Offices)",
                "صيدليات (Pharmacies)",
                "كل الأنواع (All Types)"
            ],
            default=["كل الأنواع (All Types)"]
        )
        
        st.markdown("---")
        
        # About section
        with st.expander("ℹ️ About / عن التطبيق"):
            st.markdown("""
            **Features / المميزات:**
            - ✅ Extract complete business data
            - ✅ AI categorization & analysis
            - ✅ Export to Excel/CSV
            - ✅ Mobile-friendly interface
            - ✅ Support for Arabic content
            
            **Supported Sources:**
            - Yellow Pages Egypt
            - Google Maps
            - Any business directory
            """)
    
    # Main content tabs
    tab1, tab2, tab3 = st.tabs(["🔍 Extract / استخراج", "📊 Results / النتائج", "📈 Analysis / التحليل"])
    
    # ========================================================================
    # TAB 1: EXTRACTION
    # ========================================================================
    with tab1:
        st.header("🔍 Data Extraction / استخراج البيانات")
        
        # Input method selection
        input_method = st.radio(
            "Choose input method:",
            ["📝 Enter URLs manually", "📚 Use sample URLs", "🔧 Generate Google Maps URLs"],
            horizontal=True
        )
        
        urls_to_process = []
        
        if input_method == "📝 Enter URLs manually":
            st.markdown("**Enter URLs (one per line):**")
            url_input = st.text_area(
                "URLs",
                height=150,
                placeholder="https://www.yellowpages.com.eg/en/cairo/clothing\nhttps://www.google.com/maps/search/محلات+القاهرة",
                label_visibility="collapsed"
            )
            
            if url_input:
                urls_to_process = [line.strip() for line in url_input.split('\n') if line.strip()]
        
        elif input_method == "📚 Use sample URLs":
            st.markdown("**Select category:**")
            
            sample_urls = get_sample_urls()
            selected_categories = st.multiselect(
                "Categories",
                list(sample_urls.keys()),
                default=list(sample_urls.keys())[:2],
                label_visibility="collapsed"
            )
            
            for category in selected_categories:
                urls_to_process.extend(sample_urls[category])
            
            if urls_to_process:
                st.success(f"✅ Selected {len(urls_to_process)} URLs from {len(selected_categories)} categories")
                with st.expander("View selected URLs"):
                    for i, url in enumerate(urls_to_process, 1):
                        st.text(f"{i}. {url}")
        
        elif input_method == "🔧 Generate Google Maps URLs":
            st.markdown("**Generate URLs for Google Maps search:**")
            
            col1, col2 = st.columns(2)
            
            with col1:
                categories = st.text_area(
                    "Categories (Arabic, one per line)",
                    "ملابس\nمطاعم\nصيدليات\nشركات برمجة\nعيادات",
                    height=150
                )
            
            with col2:
                cities = st.text_area(
                    "Cities (one per line)",
                    "القاهرة\nالإسكندرية\nالجيزة",
                    height=150
                )
            
            if st.button("🔧 Generate URLs"):
                categories_list = [c.strip() for c in categories.split('\n') if c.strip()]
                cities_list = [f"{c.strip()}, Egypt" for c in cities.split('\n') if c.strip()]
                
                if categories_list and cities_list:
                    gmaps = GoogleMapsExtractor()
                    urls_to_process = gmaps.generate_search_urls(categories_list, cities_list)
                    
                    st.success(f"✅ Generated {len(urls_to_process)} URLs")
                    with st.expander("View generated URLs"):
                        for i, url in enumerate(urls_to_process, 1):
                            st.text(f"{i}. {url}")
                else:
                    st.warning("⚠️ Please enter both categories and cities")
        
        st.markdown("---")
        
        # Extraction button
        if urls_to_process:
            st.info(f"📋 Ready to process **{len(urls_to_process)}** URLs with max **{max_pages}** pages each")
            
            col1, col2, col3 = st.columns([1, 2, 1])
            with col2:
                if st.button("🚀 Start Extraction", type="primary", use_container_width=True):
                    # Extraction process
                    with st.spinner("🔄 Extracting data... This may take a few minutes..."):
                        try:
                            # Create extractor
                            extractor = ShopDataExtractor()
                            
                            # Progress bar
                            progress_bar = st.progress(0)
                            status_text = st.empty()
                            
                            # Extract data
                            status_text.text("📥 Extracting data from URLs...")
                            progress_bar.progress(30)
                            
                            df = extractor.scrape_multiple_urls(urls_to_process, max_pages_per_url=max_pages)
                            
                            if df.empty:
                                st.error("❌ No data extracted. Please check your URLs and try again.")
                                st.stop()
                            
                            progress_bar.progress(60)
                            st.session_state.extracted_data = df
                            
                            # AI Analysis
                            if enable_ai:
                                status_text.text("🤖 Running AI analysis...")
                                progress_bar.progress(80)
                                
                                analyzer = ShopAIAnalyzer()
                                df = analyzer.analyze_dataframe(df)
                                st.session_state.analyzed_data = df
                            else:
                                st.session_state.analyzed_data = df
                            
                            progress_bar.progress(100)
                            status_text.text("✅ Extraction complete!")
                            
                            st.session_state.extraction_complete = True
                            
                            # Success message
                            st.success(f"""
                            ✅ **Extraction Complete!**
                            - Total businesses: **{len(df)}**
                            - With phone: **{df['phone'].notna().sum()}**
                            - With email: **{df['email'].notna().sum()}**
                            - With social media: **{df[['instagram', 'facebook']].notna().any(axis=1).sum()}**
                            """)
                            
                            st.balloons()
                            
                        except Exception as e:
                            st.error(f"❌ Error during extraction: {str(e)}")
                            st.exception(e)
        else:
            st.warning("⚠️ Please select or enter URLs to process")
    
    # ========================================================================
    # TAB 2: RESULTS
    # ========================================================================
    with tab2:
        st.header("📊 Extraction Results / نتائج الاستخراج")
        
        if st.session_state.extraction_complete and st.session_state.analyzed_data is not None:
            df = st.session_state.analyzed_data
            
            # Statistics cards
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.markdown(f"""
                <div class="stats-card">
                    <p class="stats-number">{len(df)}</p>
                    <p class="stats-label">Total Businesses</p>
                </div>
                """, unsafe_allow_html=True)
            
            with col2:
                st.markdown(f"""
                <div class="stats-card">
                    <p class="stats-number">{df['phone'].notna().sum()}</p>
                    <p class="stats-label">With Phone</p>
                </div>
                """, unsafe_allow_html=True)
            
            with col3:
                st.markdown(f"""
                <div class="stats-card">
                    <p class="stats-number">{df['email'].notna().sum()}</p>
                    <p class="stats-label">With Email</p>
                </div>
                """, unsafe_allow_html=True)
            
            with col4:
                st.markdown(f"""
                <div class="stats-card">
                    <p class="stats-number">{df[['instagram', 'facebook']].notna().any(axis=1).sum()}</p>
                    <p class="stats-label">With Social</p>
                </div>
                """, unsafe_allow_html=True)
            
            st.markdown("---")
            
            # Filters
            st.subheader("🔎 Filter Results")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                search_term = st.text_input("🔍 Search by name", "")
            
            with col2:
                if 'ai_category' in df.columns:
                    categories = ['All'] + list(df['ai_category'].dropna().unique())
                    selected_category = st.selectbox("📁 Category", categories)
                else:
                    selected_category = 'All'
            
            with col3:
                if 'revenue_rating' in df.columns:
                    ratings = ['All'] + list(df['revenue_rating'].dropna().unique())
                    selected_rating = st.selectbox("⭐ Revenue Rating", ratings)
                else:
                    selected_rating = 'All'
            
            # Apply filters
            filtered_df = df.copy()
            
            if search_term:
                filtered_df = filtered_df[
                    filtered_df['shop_name'].str.contains(search_term, case=False, na=False)
                ]
            
            if selected_category != 'All' and 'ai_category' in df.columns:
                filtered_df = filtered_df[filtered_df['ai_category'] == selected_category]
            
            if selected_rating != 'All' and 'revenue_rating' in df.columns:
                filtered_df = filtered_df[filtered_df['revenue_rating'] == selected_rating]
            
            st.info(f"Showing **{len(filtered_df)}** of **{len(df)}** businesses")
            
            # Display dataframe
            st.dataframe(
                format_dataframe_for_display(filtered_df),
                use_container_width=True,
                height=400
            )
            
            # Export buttons
            st.markdown("---")
            st.subheader("💾 Export Data")
            
            col1, col2 = st.columns(2)
            
            with col1:
                # Excel export
                excel_data = export_to_excel(filtered_df)
                st.download_button(
                    label="📗 Download Excel",
                    data=excel_data,
                    file_name=f"egyptian_businesses_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    use_container_width=True
                )
            
            with col2:
                # CSV export
                csv_data = filtered_df.to_csv(index=False, encoding='utf-8-sig')
                st.download_button(
                    label="📄 Download CSV",
                    data=csv_data,
                    file_name=f"egyptian_businesses_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv",
                    use_container_width=True
                )
        
        else:
            st.info("👆 Please extract data first from the 'Extract' tab")
    
    # ========================================================================
    # TAB 3: ANALYSIS
    # ========================================================================
    with tab3:
        st.header("📈 AI Analysis / التحليل الذكي")
        
        if st.session_state.extraction_complete and st.session_state.analyzed_data is not None:
            df = st.session_state.analyzed_data
            
            if enable_ai and 'ai_category' in df.columns:
                # Category distribution
                st.subheader("📊 Category Distribution")
                
                category_counts = df['ai_category'].value_counts()
                st.bar_chart(category_counts)
                
                # Revenue rating distribution
                if 'revenue_rating' in df.columns:
                    st.markdown("---")
                    st.subheader("💰 Revenue Rating Distribution")
                    
                    rating_counts = df['revenue_rating'].value_counts()
                    
                    col1, col2 = st.columns([2, 1])
                    
                    with col1:
                        st.bar_chart(rating_counts)
                    
                    with col2:
                        st.markdown("**Legend:**")
                        for rating, count in rating_counts.items():
                            percentage = (count / len(df)) * 100
                            st.metric(rating, f"{count}", f"{percentage:.1f}%")
                
                # Top insights
                st.markdown("---")
                st.subheader("🎯 Key Insights")
                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown("**Top Categories:**")
                    for i, (cat, count) in enumerate(category_counts.head(5).items(), 1):
                        st.write(f"{i}. **{cat}**: {count} businesses")
                
                with col2:
                    st.markdown("**Contact Completeness:**")
                    complete_contacts = df[
                        df['phone'].notna() & 
                        df['email'].notna() & 
                        (df[['instagram', 'facebook']].notna().any(axis=1))
                    ]
                    st.metric(
                        "Complete profiles",
                        f"{len(complete_contacts)}",
                        f"{(len(complete_contacts)/len(df)*100):.1f}%"
                    )
                
                # Generate full report
                st.markdown("---")
                if st.button("📄 Generate Full Analysis Report"):
                    with st.spinner("Generating report..."):
                        analyzer = ShopAIAnalyzer()
                        report = analyzer.generate_insights_report(df)
                        
                        st.text_area("Analysis Report", report, height=400)
                        
                        # Download report
                        st.download_button(
                            label="💾 Download Report",
                            data=report,
                            file_name=f"analysis_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
                            mime="text/plain"
                        )
            
            else:
                st.info("🤖 Enable AI Analysis in settings to see detailed insights")
        
        else:
            st.info("👆 Please extract data first from the 'Extract' tab")
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style='text-align: center; color: #666; padding: 2rem 0;'>
        <p>🛍️ <strong>Egyptian Business Data Extractor</strong></p>
        <p class='rtl'>أداة احترافية لاستخراج وتحليل بيانات الأعمال المصرية</p>
        <p style='font-size: 0.8rem;'>Made with ❤️ for Egyptian entrepreneurs</p>
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
