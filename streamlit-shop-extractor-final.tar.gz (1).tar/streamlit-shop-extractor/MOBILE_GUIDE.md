# 📱 تشغيل التطبيق على الموبايل مباشرة
# Run App on Mobile Directly

## 🚀 الطريقة السريعة - Termux (Android)

### خطوة 1: تثبيت Termux
1. حمّل Termux من F-Droid (موصى به) أو Google Play
2. افتح التطبيق

### خطوة 2: تثبيت Python
```bash
# تحديث الباكجات
pkg update && pkg upgrade -y

# تثبيت Python و Git
pkg install python python-pip git -y

# التحقق من التثبيت
python --version
```

### خطوة 3: إعداد المشروع
```bash
# السماح بالوصول للملفات
termux-setup-storage

# الانتقال لمجلد Downloads
cd ~/storage/downloads

# إذا كان المشروع في ملف مضغوط
tar -xf streamlit-shop-extractor.tar.gz
cd streamlit-shop-extractor

# أو استنساخ من GitHub (إذا رفعته)
# git clone https://github.com/your-username/streamlit-shop-extractor.git
# cd streamlit-shop-extractor
```

### خطوة 4: تثبيت المتطلبات
```bash
# تثبيت المكتبات الأساسية
pip install streamlit pandas openpyxl beautifulsoup4 requests

# تثبيت باقي المكتبات
pip install phonenumbers email-validator tqdm fake-useragent retry python-dotenv

# للميزات المتقدمة (اختياري - قد يستغرق وقتاً)
# pip install playwright selenium
```

### خطوة 5: تشغيل التطبيق
```bash
# تشغيل Streamlit
streamlit run app.py --server.headless true --server.port 8501

# أو استخدم الأمر المختصر
python -m streamlit run app.py
```

### خطوة 6: فتح التطبيق
1. افتح المتصفح على الموبايل (Chrome أو Firefox)
2. اذهب إلى: `http://localhost:8501`
3. استمتع! 🎉

---

## 🌐 الطريقة البديلة - استخدام Cloud (بدون Termux)

### الخيار 1: Streamlit Cloud (مجاني)

#### الخطوات:
1. **رفع المشروع على GitHub:**
   - اذهب لـ [github.com](https://github.com)
   - أنشئ حساب (إذا لم يكن لديك)
   - اضغط "New Repository"
   - ارفع كل ملفات المشروع

2. **النشر على Streamlit Cloud:**
   - اذهب لـ [share.streamlit.io](https://share.streamlit.io)
   - سجّل دخول بحساب GitHub
   - اضغط "New app"
   - اختر repository الخاص بك
   - اضبط الإعدادات:
     - Main file: `app.py`
     - Python version: 3.8+
   - اضغط "Deploy"

3. **الوصول للتطبيق:**
   - احصل على رابط مثل: `https://your-app.streamlit.app`
   - افتحه من أي موبايل/كمبيوتر
   - شاركه مع فريقك

**المميزات:**
- ✅ مجاني تماماً
- ✅ يعمل 24/7
- ✅ سهل المشاركة
- ✅ تحديث تلقائي
- ✅ بدون صيانة

### الخيار 2: PythonAnywhere (مجاني)

```bash
# بعد إنشاء حساب على pythonanywhere.com:
# 1. افتح Bash Console
# 2. استنسخ المشروع
git clone https://github.com/your-repo/streamlit-shop-extractor.git

# 3. تثبيت المكتبات
pip install --user -r streamlit-shop-extractor/requirements.txt

# 4. تشغيل التطبيق
cd streamlit-shop-extractor
streamlit run app.py --server.port 8000
```

---

## 📲 تثبيت التطبيق كـ PWA (مثل التطبيق الحقيقي)

### Android (Chrome):
1. افتح التطبيق في Chrome
2. اضغط القائمة (⋮) أعلى اليمين
3. اختر "Install app" أو "إضافة إلى الشاشة الرئيسية"
4. اضغط "Install"
5. التطبيق يظهر على الشاشة الرئيسية!

### iOS (Safari):
1. افتح التطبيق في Safari
2. اضغط زر المشاركة (⬆️)
3. اختر "Add to Home Screen"
4. اضغط "Add"
5. التطبيق جاهز!

**المميزات:**
- يعمل مثل التطبيق العادي
- يفتح في شاشة كاملة
- أيقونة على الشاشة الرئيسية
- يعمل بدون إنترنت (بعد التحميل الأول)

---

## 🎯 نصائح للأداء الأفضل على الموبايل

### 1. تقليل استهلاك البطارية
```bash
# في Termux، استخدم:
streamlit run app.py --server.headless true --server.runOnSave false
```

### 2. توفير البيانات
- استخرج من 3-5 صفحات بدلاً من 10
- استخدم WiFi بدلاً من بيانات الموبايل
- عطّل AI Analysis إذا لم تكن بحاجة له

### 3. تحسين السرعة
- أغلق التطبيقات الأخرى
- امسح ذاكرة التخزين المؤقت
- استخدم متصفح Chrome (الأسرع)

### 4. توفير المساحة
```bash
# في Termux، امسح الملفات المؤقتة:
pip cache purge
streamlit cache clear
```

---

## 🔧 حل المشاكل الشائعة

### المشكلة: Termux لا يعمل
```bash
# أعد تثبيت Python
pkg reinstall python

# تحديث pip
pip install --upgrade pip
```

### المشكلة: خطأ في تثبيت المكتبات
```bash
# ثبّت المكتبات واحدة واحدة
pip install streamlit
pip install pandas
pip install beautifulsoup4
pip install requests
pip install openpyxl
```

### المشكلة: التطبيق بطيء
- قلل max_pages إلى 3-5
- عطّل AI Analysis
- استخدم WiFi سريع
- أغلق التبويبات الأخرى

### المشكلة: النص العربي مكسور
```bash
# في Termux، ثبّت دعم Unicode:
pkg install ncurses-utils
export LANG=en_US.UTF-8
```

### المشكلة: التطبيق يتوقف
```bash
# في Termux، استخدم screen للحفاظ على الجلسة:
pkg install screen
screen -S streamlit
streamlit run app.py
# اضغط Ctrl+A ثم D للخروج مع بقاء التطبيق يعمل
# screen -r streamlit للعودة
```

---

## 📦 إنشاء ملف APK (متقدم)

إذا أردت تطبيق Android حقيقي (APK):

### استخدم Buildozer (Linux/Termux)
```bash
# تثبيت Buildozer
pip install buildozer

# إنشاء buildozer.spec
buildozer init

# تعديل buildozer.spec:
# - requirements = kivy,streamlit,pandas,...
# - title = Egyptian Business Extractor
# - package.name = shopextractor

# بناء APK
buildozer android debug

# APK في: bin/shopextractor-0.1-debug.apk
```

### أو استخدم Kivy (بديل أسهل)
سيتطلب إعادة كتابة الواجهة - اتصل إذا احتجت مساعدة!

---

## 🌟 الطريقة الأسهل (للمبتدئين)

### إذا كنت لا تريد Termux أو Cloud:

**استخدم Replit:**
1. اذهب لـ [replit.com](https://replit.com)
2. أنشئ حساب مجاني
3. اضغط "Create Repl"
4. اختر "Python"
5. ارفع الملفات
6. اضغط "Run"
7. احصل على رابط عام!

**المميزات:**
- ✅ بدون تثبيت أي شيء
- ✅ يعمل من المتصفح
- ✅ مجاني
- ✅ سهل جداً

---

## 🎓 فيديوهات تعليمية (موصى بها)

### لتعلم Termux:
- ابحث على YouTube عن: "Termux Python tutorial"
- ابحث عن: "تشغيل Python على الموبايل"

### لتعلم Streamlit Cloud:
- ابحث عن: "Streamlit Cloud deployment"
- شاهد: "Deploy Streamlit app free"

---

## 💡 نصائح إضافية

### للاستخدام اليومي:
1. **استخدم Cloud** إذا كان لديك إنترنت مستقر
2. **استخدم Termux** إذا أردت العمل بدون إنترنت
3. **ثبّت كـ PWA** لتجربة أفضل

### للفرق:
1. **انشر على Streamlit Cloud** وشارك الرابط
2. **أضف كلمة مرور** (في Streamlit Cloud settings)
3. **راقب الاستخدام** (في Dashboard)

### للمطورين:
1. **استخدم Git** للتحديثات
2. **اختبر Local** أولاً
3. **انشر على Cloud** للإنتاج

---

## 📞 الدعم

### أسئلة شائعة:

**س: هل يعمل بدون إنترنت؟**
ج: لا، يحتاج إنترنت لاستخراج البيانات.

**س: هل يستهلك بيانات كثيرة؟**
ج: معتدل، حوالي 10-50 MB لكل جلسة.

**س: هل يعمل على iOS؟**
ج: نعم! استخدم Cloud أو Safari PWA.

**س: هل آمن؟**
ج: نعم، كل البيانات على جهازك أو Cloud الخاص بك.

---

**🎉 الآن جاهز! شغّل التطبيق واستمتع بالاستخراج السهل للبيانات!**

<div dir="rtl">

## 🇪🇬 للمطورين المصريين

إذا واجهت أي مشكلة:
1. تأكد من تثبيت Python بشكل صحيح
2. استخدم WiFi مستقر
3. جرّب الأمثلة الموجودة أولاً
4. راجع الأخطاء في Terminal

**حظاً موفقاً! 🚀**

</div>
