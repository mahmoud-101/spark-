#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Egyptian Shop Data Extractor
Extracts shop information from Google Maps, Yellow Pages, and other Egyptian business directories.
Supports Arabic content and dynamic pagination.
"""

import re
import time
import json
import logging
from typing import List, Dict, Optional
from urllib.parse import urlparse, parse_qs, urljoin
import pandas as pd
from bs4 import BeautifulSoup
import requests
from fake_useragent import UserAgent
from tqdm import tqdm
import phonenumbers
from email_validator import validate_email, EmailNotValidError

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('extractor.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class ShopDataExtractor:
    """Main extractor class for Egyptian shop data"""
    
    def __init__(self):
        self.user_agent = UserAgent()
        self.session = requests.Session()
        self.extracted_data = []
        
    def get_headers(self) -> Dict:
        """Generate headers with random user agent"""
        return {
            'User-Agent': self.user_agent.random,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'ar,en-US;q=0.7,en;q=0.3',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        }
    
    def extract_phone_numbers(self, text: str) -> List[str]:
        """Extract Egyptian phone numbers from text"""
        phones = []
        
        # Egyptian phone patterns
        patterns = [
            r'\+20\s?\d{10}',  # +20 1234567890
            r'00\s?20\s?\d{10}',  # 0020 1234567890
            r'0\d{10}',  # 01234567890
            r'\d{3}[-\s]?\d{4}[-\s]?\d{4}',  # 012-3456-7890
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, text)
            phones.extend(matches)
        
        # Validate and standardize
        validated_phones = []
        for phone in phones:
            try:
                # Clean the number
                cleaned = re.sub(r'[-\s]', '', phone)
                if not cleaned.startswith('+'):
                    if cleaned.startswith('00'):
                        cleaned = '+' + cleaned[2:]
                    elif cleaned.startswith('0'):
                        cleaned = '+20' + cleaned[1:]
                    else:
                        cleaned = '+20' + cleaned
                
                # Validate with phonenumbers library
                parsed = phonenumbers.parse(cleaned, "EG")
                if phonenumbers.is_valid_number(parsed):
                    formatted = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.E164)
                    validated_phones.append(formatted)
            except Exception as e:
                logger.debug(f"Phone validation error for {phone}: {e}")
                continue
        
        return list(set(validated_phones))  # Remove duplicates
    
    def extract_emails(self, text: str) -> List[str]:
        """Extract and validate email addresses"""
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        emails = re.findall(email_pattern, text)
        
        validated_emails = []
        for email in emails:
            try:
                valid = validate_email(email)
                validated_emails.append(valid.email)
            except EmailNotValidError:
                continue
        
        return list(set(validated_emails))
    
    def extract_social_links(self, soup: BeautifulSoup, base_url: str) -> Dict[str, str]:
        """Extract Instagram, Facebook, and other social media links"""
        social = {
            'instagram': '',
            'facebook': '',
            'whatsapp': '',
            'twitter': '',
            'tiktok': ''
        }
        
        # Find all links
        for link in soup.find_all('a', href=True):
            href = link['href'].lower()
            
            if 'instagram.com' in href:
                social['instagram'] = link['href']
            elif 'facebook.com' in href or 'fb.com' in href:
                social['facebook'] = link['href']
            elif 'wa.me' in href or 'whatsapp' in href:
                social['whatsapp'] = link['href']
            elif 'twitter.com' in href or 'x.com' in href:
                social['twitter'] = link['href']
            elif 'tiktok.com' in href:
                social['tiktok'] = link['href']
        
        return social
    
    def extract_shop_data_from_page(self, html: str, url: str) -> List[Dict]:
        """Extract shop data from a single page"""
        soup = BeautifulSoup(html, 'html.parser')
        shops = []
        
        # Strategy 1: Look for common business listing patterns
        # This is a generic extractor that works with most directory sites
        
        # Common container classes for business listings
        listing_containers = soup.find_all(['div', 'article', 'section'], 
                                          class_=re.compile(r'(listing|business|shop|store|item|card|result)', re.I))
        
        if not listing_containers:
            # Fallback: try to find structured data
            listing_containers = soup.find_all(['div', 'article'], 
                                              attrs={'itemtype': re.compile(r'schema.org/(Local)?Business')})
        
        logger.info(f"Found {len(listing_containers)} potential shop listings")
        
        for container in listing_containers:
            shop_data = {
                'shop_name': '',
                'phone': '',
                'whatsapp': '',
                'email': '',
                'address': '',
                'instagram': '',
                'facebook': '',
                'website': '',
                'products': '',
                'prices': '',
                'category': '',
                'source_url': url
            }
            
            # Extract shop name
            name_tags = container.find_all(['h1', 'h2', 'h3', 'h4', 'a'], 
                                          class_=re.compile(r'(name|title|heading)', re.I))
            if name_tags:
                shop_data['shop_name'] = name_tags[0].get_text(strip=True)
            
            # Extract all text content for phone/email extraction
            container_text = container.get_text()
            
            # Extract phones
            phones = self.extract_phone_numbers(container_text)
            if phones:
                shop_data['phone'] = ', '.join(phones[:3])  # Limit to 3 phones
            
            # Extract emails
            emails = self.extract_emails(container_text)
            if emails:
                shop_data['email'] = ', '.join(emails[:2])  # Limit to 2 emails
            
            # Extract address
            address_tags = container.find_all(['span', 'div', 'p'], 
                                            class_=re.compile(r'address|location', re.I))
            if address_tags:
                shop_data['address'] = address_tags[0].get_text(strip=True)
            
            # Extract social links
            social = self.extract_social_links(container, url)
            shop_data.update(social)
            
            # Extract WhatsApp from phones if not found
            if not shop_data['whatsapp'] and shop_data['phone']:
                first_phone = shop_data['phone'].split(',')[0].strip()
                shop_data['whatsapp'] = f"https://wa.me/{first_phone.replace('+', '')}"
            
            # Extract website
            website_links = container.find_all('a', href=re.compile(r'^https?://'))
            for link in website_links:
                href = link['href']
                if 'facebook' not in href and 'instagram' not in href and 'twitter' not in href:
                    shop_data['website'] = href
                    break
            
            # Extract products/services
            product_tags = container.find_all(['span', 'div', 'p'], 
                                            class_=re.compile(r'product|service|category|tag', re.I))
            if product_tags:
                shop_data['products'] = ', '.join([t.get_text(strip=True) for t in product_tags[:5]])
            
            # Only add if we have at least a name
            if shop_data['shop_name']:
                shops.append(shop_data)
        
        return shops
    
    def find_next_page_url(self, soup: BeautifulSoup, current_url: str) -> Optional[str]:
        """Find the next page URL for pagination"""
        
        # Common pagination patterns
        next_patterns = [
            {'name': 'a', 'class_': re.compile(r'next', re.I)},
            {'name': 'a', 'text': re.compile(r'التالي|next|›|»|>', re.I)},
            {'name': 'a', 'attrs': {'rel': 'next'}},
            {'name': 'button', 'class_': re.compile(r'next', re.I)},
        ]
        
        for pattern in next_patterns:
            next_link = soup.find(**pattern)
            if next_link and next_link.get('href'):
                next_url = urljoin(current_url, next_link['href'])
                logger.info(f"Found next page: {next_url}")
                return next_url
        
        # Check for numbered pagination
        page_links = soup.find_all('a', href=True, text=re.compile(r'\d+'))
        if page_links:
            # Get current page number from URL
            current_page = 1
            if 'page=' in current_url:
                match = re.search(r'page=(\d+)', current_url)
                if match:
                    current_page = int(match.group(1))
            
            # Find next page number
            for link in page_links:
                try:
                    page_num = int(link.get_text(strip=True))
                    if page_num == current_page + 1:
                        return urljoin(current_url, link['href'])
                except ValueError:
                    continue
        
        return None
    
    def scrape_url(self, url: str, max_pages: int = 10) -> List[Dict]:
        """Scrape data from a URL with pagination support"""
        all_shops = []
        current_url = url
        
        for page_num in range(1, max_pages + 1):
            logger.info(f"Scraping page {page_num}: {current_url}")
            
            try:
                response = self.session.get(
                    current_url, 
                    headers=self.get_headers(),
                    timeout=30
                )
                response.raise_for_status()
                
                # Extract shops from current page
                shops = self.extract_shop_data_from_page(response.text, current_url)
                all_shops.extend(shops)
                logger.info(f"Extracted {len(shops)} shops from page {page_num}")
                
                # Find next page
                soup = BeautifulSoup(response.text, 'html.parser')
                next_url = self.find_next_page_url(soup, current_url)
                
                if not next_url or next_url == current_url:
                    logger.info(f"No more pages found after page {page_num}")
                    break
                
                current_url = next_url
                
                # Be polite - wait between requests
                time.sleep(2)
                
            except Exception as e:
                logger.error(f"Error scraping {current_url}: {e}")
                break
        
        return all_shops
    
    def scrape_multiple_urls(self, urls: List[str], max_pages_per_url: int = 10) -> pd.DataFrame:
        """Scrape multiple URLs and return combined DataFrame"""
        all_data = []
        
        for url in tqdm(urls, desc="Scraping URLs"):
            logger.info(f"\n{'='*50}\nScraping: {url}\n{'='*50}")
            shops = self.scrape_url(url, max_pages=max_pages_per_url)
            all_data.extend(shops)
            time.sleep(3)  # Wait between different URLs
        
        df = pd.DataFrame(all_data)
        
        # Remove duplicates based on shop name and phone
        if not df.empty:
            df = df.drop_duplicates(subset=['shop_name', 'phone'], keep='first')
            logger.info(f"\nTotal unique shops extracted: {len(df)}")
        
        return df
    
    def clean_and_export(self, df: pd.DataFrame, output_file: str = 'egyptian_shops.xlsx'):
        """Clean data and export to Excel"""
        if df.empty:
            logger.warning("No data to export!")
            return
        
        # Clean empty strings
        df = df.replace('', pd.NA)
        
        # Remove rows with no contact information
        df = df.dropna(subset=['phone', 'email', 'whatsapp'], how='all')
        
        # Sort by shop name
        df = df.sort_values('shop_name')
        
        # Export to Excel with formatting
        with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name='Egyptian Shops')
            
            # Auto-adjust column widths
            worksheet = writer.sheets['Egyptian Shops']
            for idx, col in enumerate(df.columns):
                max_length = max(
                    df[col].astype(str).apply(len).max(),
                    len(col)
                ) + 2
                worksheet.column_dimensions[chr(65 + idx)].width = min(max_length, 50)
        
        logger.info(f"Data exported to {output_file}")
        logger.info(f"Total shops: {len(df)}")
        logger.info(f"Shops with phone: {df['phone'].notna().sum()}")
        logger.info(f"Shops with email: {df['email'].notna().sum()}")
        logger.info(f"Shops with social media: {df['instagram'].notna().sum() + df['facebook'].notna().sum()}")


def main():
    """Main execution function"""
    
    # Example URLs for Egyptian shops
    urls = [
        # Google Maps searches (Note: These are example URLs, actual scraping may need Google Maps API)
        "https://www.yellowpages.com.eg/en/cairo/clothing",
        # Add your URLs here
    ]
    
    print("🛍️  Egyptian Shop Data Extractor")
    print("="*50)
    print("\nThis tool extracts shop data from Egyptian business directories.")
    print("Supports: Google Maps, Yellow Pages, and other directories")
    print("\nFeatures:")
    print("✅ Phone number extraction & validation")
    print("✅ Email extraction & validation")
    print("✅ Social media links (Instagram, Facebook, WhatsApp)")
    print("✅ Address and product information")
    print("✅ Automatic pagination (up to 10 pages)")
    print("✅ Arabic content support")
    print("\n" + "="*50)
    
    # Get URLs from user
    print("\nEnter URLs to scrape (one per line, press Enter twice when done):")
    user_urls = []
    while True:
        line = input()
        if not line:
            break
        user_urls.append(line.strip())
    
    if user_urls:
        urls = user_urls
    
    if not urls:
        print("❌ No URLs provided. Using example URLs...")
        print("Note: For actual scraping, please provide valid URLs.")
        return
    
    # Initialize extractor
    extractor = ShopDataExtractor()
    
    # Scrape data
    print(f"\n🚀 Starting extraction from {len(urls)} URL(s)...")
    df = extractor.scrape_multiple_urls(urls, max_pages_per_url=10)
    
    # Export results
    if not df.empty:
        output_file = 'egyptian_shops_data.xlsx'
        extractor.clean_and_export(df, output_file)
        print(f"\n✅ Success! Data saved to: {output_file}")
        print(f"📊 Total shops extracted: {len(df)}")
    else:
        print("\n❌ No data extracted. Please check your URLs and try again.")


if __name__ == "__main__":
    main()
