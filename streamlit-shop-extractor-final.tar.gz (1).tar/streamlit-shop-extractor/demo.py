#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Demo Script - Egyptian Shop Extractor
Demonstrates all features with sample data
"""

from extractor import ShopDataExtractor
from ai_analyzer import ShopAIAnalyzer
import pandas as pd


def create_demo_data():
    """Create sample shop data for demonstration"""
    
    sample_shops = [
        {
            'shop_name': 'بوتيك الأناقة - مول العرب',
            'phone': '+201234567890, +201234567891',
            'email': 'info@elegance.com',
            'address': 'مول العرب، الشيخ زايد، الجيزة',
            'instagram': '@elegance_boutique',
            'facebook': 'facebook.com/eleganceboutique',
            'whatsapp': 'https://wa.me/201234567890',
            'website': 'www.elegance.com',
            'products': 'فساتين سهرة، ملابس كاجوال، إكسسوارات نسائية',
            'prices': '500-3000 جنيه',
            'category': 'clothing',
            'source_url': 'https://example.com'
        },
        {
            'shop_name': 'مطعم الفلاح للمأكولات المصرية',
            'phone': '+20100000001',
            'email': '',
            'address': 'شارع الهرم، الجيزة',
            'instagram': '',
            'facebook': 'facebook.com/fallah',
            'whatsapp': 'https://wa.me/20100000001',
            'website': '',
            'products': 'كشري، فول، طعمية، محشي',
            'prices': '20-80 جنيه',
            'category': 'food',
            'source_url': 'https://example.com'
        },
        {
            'shop_name': 'صيدلية النور - فرع مدينة نصر',
            'phone': '+20100000002',
            'email': 'nour.pharmacy@gmail.com',
            'address': 'شارع عباس العقاد، مدينة نصر، القاهرة',
            'instagram': '@nourpharmacy',
            'facebook': 'facebook.com/nourpharmacy',
            'whatsapp': 'https://wa.me/20100000002',
            'website': 'www.nourpharmacy.com',
            'products': 'أدوية، مستحضرات تجميل، فيتامينات، منتجات عناية بالبشرة',
            'prices': '',
            'category': 'pharmacy',
            'source_url': 'https://example.com'
        },
        {
            'shop_name': 'موبايلات الأسرة',
            'phone': '+20100000003',
            'email': '',
            'address': 'شارع فيصل، الجيزة',
            'instagram': '',
            'facebook': '',
            'whatsapp': 'https://wa.me/20100000003',
            'website': '',
            'products': 'موبايلات، إكسسوارات، صيانة',
            'prices': '',
            'category': 'electronics',
            'source_url': 'https://example.com'
        },
        {
            'shop_name': 'كافيه سيتي ستارز',
            'phone': '+20100000004, +20100000005',
            'email': 'citystars.cafe@hotmail.com',
            'address': 'سيتي ستارز مول، مدينة نصر، القاهرة',
            'instagram': '@citystars_cafe',
            'facebook': 'facebook.com/citystarscafe',
            'whatsapp': 'https://wa.me/20100000004',
            'website': 'www.citystarscafe.com',
            'products': 'قهوة، مشروبات ساخنة، حلويات، سندويتشات',
            'prices': '30-150 جنيه',
            'category': 'food',
            'source_url': 'https://example.com'
        }
    ]
    
    return pd.DataFrame(sample_shops)


def run_demo():
    """Run complete demo"""
    
    print("""
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║              🎬 DEMO: EGYPTIAN SHOP EXTRACTOR & ANALYZER            ║
║                                                                      ║
║                     عرض توضيحي للأداة الكاملة                        ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
    """)
    
    # Create sample data
    print("\n1️⃣  Creating sample Egyptian shop data...")
    df = create_demo_data()
    print(f"✅ Created {len(df)} sample shops\n")
    
    # Display raw data
    print("=" * 80)
    print("📊 RAW DATA (Before AI Analysis)")
    print("=" * 80)
    print(df[['shop_name', 'phone', 'email', 'address', 'category']].to_string())
    print("\n")
    
    # Run AI Analysis
    print("=" * 80)
    print("2️⃣  Running AI Analysis...")
    print("=" * 80)
    
    analyzer = ShopAIAnalyzer()
    df_analyzed = analyzer.analyze_dataframe(df)
    
    # Display analyzed data
    print("\n" + "=" * 80)
    print("🤖 ANALYZED DATA (After AI Analysis)")
    print("=" * 80)
    print(df_analyzed[['shop_name', 'ai_category', 'revenue_score', 'revenue_rating']].to_string())
    print("\n")
    
    # Generate insights report
    print("=" * 80)
    print("3️⃣  Generating Insights Report...")
    print("=" * 80)
    
    report = analyzer.generate_insights_report(df_analyzed)
    print(report)
    
    # Export data
    print("\n" + "=" * 80)
    print("4️⃣  Exporting Data...")
    print("=" * 80)
    
    extractor = ShopDataExtractor()
    
    # Export to Excel
    output_file = 'demo_egyptian_shops.xlsx'
    extractor.clean_and_export(df_analyzed, output_file)
    print(f"✅ Excel file created: {output_file}")
    
    # Export to CSV
    csv_file = 'demo_egyptian_shops.csv'
    df_analyzed.to_csv(csv_file, index=False, encoding='utf-8-sig')
    print(f"✅ CSV file created: {csv_file}")
    
    # Save report
    report_file = 'demo_analysis_report.txt'
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write(report)
    print(f"✅ Report saved: {report_file}")
    
    print("\n" + "=" * 80)
    print("🎉 DEMO COMPLETE!")
    print("=" * 80)
    print("\n✨ Check the generated files:")
    print(f"   • {output_file} - Excel with full data")
    print(f"   • {csv_file} - CSV format")
    print(f"   • {report_file} - Analysis report")
    print("\n💡 Next steps:")
    print("   1. Run 'python main.py -i' for interactive extraction")
    print("   2. Provide real URLs to extract actual shop data")
    print("   3. Integrate with your Sellfast SaaS platform")
    print("\n" + "=" * 80)


if __name__ == "__main__":
    run_demo()
